"""Minimal loader for UCR/UEA .ts univariate files (no sktime dependency)."""
import os
import numpy as np

from paths import DATA as ROOT


def read_ts(path):
    meta, rows, labels, in_data = {}, [], [], False
    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if not in_data:
                if line.lower().startswith("@data"):
                    in_data = True
                elif line.startswith("@"):
                    parts = line[1:].split(None, 1)
                    meta[parts[0].lower()] = parts[1] if len(parts) > 1 else ""
                continue
            if meta.get("classlabel", "false").startswith("true"):
                series, lab = line.rsplit(":", 1)
                labels.append(lab.strip())
            else:
                series = line
            vals = [np.nan if v in ("?", "NaN", "nan", "") else float(v) for v in series.split(",")]
            rows.append(np.array(vals))
    return meta, rows, labels


def load(name, with_labels=False):
    """Return (train, test, meta[, ytrain, ytest]); arrays are (N, n) when equal length."""
    out, labs = [], []
    for split in ("TRAIN", "TEST"):
        meta, rows, labels = read_ts(os.path.join(ROOT, name, f"{name}_{split}.ts"))
        lens = {len(r) for r in rows}
        out.append(np.vstack(rows) if len(lens) == 1 else rows)
        labs.append(np.array(labels))
    if with_labels:
        return out[0], out[1], meta, labs[0], labs[1]
    return out[0], out[1], meta


def datasets():
    return sorted(d for d in os.listdir(ROOT) if os.path.isdir(os.path.join(ROOT, d)))
