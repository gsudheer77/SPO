"""Qualitative examples, controlled training-size sweep and training-budget figures/tables."""
import os
import glob
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

from analysis import COLOR, LABEL, INK, INK2, OUTD, TASK_LABEL

import paths
HERE = os.path.dirname(os.path.abspath(__file__))


def examples():
    z = np.load(os.path.join(paths.MAIN, "examples_ECG5000.npz"))
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 4.4), sharex=True)
    for ax, t in zip(axes.flat, ["denoise", "deconv", "gaps", "down"]):
        i = 0
        f = z[f"{t}__f"][i]
        x = np.arange(len(f))
        mu, sd = z[f"{t}__GaussPrior"][i], z[f"{t}__gp_sd"][i]
        ax.fill_between(x, mu - 1.645 * sd, mu + 1.645 * sd, color="#cfe0f6", lw=0, label="90% interval (Gaussian prior)")
        g = z[f"{t}__g"][i]
        if t == "gaps":
            m = z[f"{t}__mask"][i].astype(bool)
            ax.plot(x[m], g[m], "o", ms=2.2, color=INK2, label="Observed")
        elif t == "down":
            r = 4
            ax.step(np.arange(len(g)) * r, g, where="post", color=INK2, lw=1.0, label="Observed (4x averages)")
        else:
            ax.plot(x, g, color=INK2, lw=0.8, alpha=0.8, label="Observed")
        ax.plot(x, f, color=INK, lw=1.6, label="True series")
        for m in ["Tikhonov", "GaussPrior", "LGD", "DirectCNN"]:
            ax.plot(x, z[f"{t}__{m}"][i], color=COLOR[m], lw=1.1, label=LABEL[m])
        ax.set_title(TASK_LABEL[t], fontsize=9)
    h, l = axes[0, 0].get_legend_handles_labels()
    order = ["True series", "Observed", "Tikhonov", "Learned Gaussian prior", "Unrolled LGD", "Fully learned CNN",
             "90% interval (Gaussian prior)"]
    hh = [h[l.index(o)] for o in order]
    fig.legend(hh, order, loc="lower center", ncol=4, fontsize=7, bbox_to_anchor=(0.5, -0.07))
    for ax in axes[1]:
        ax.set_xlabel("Time index")
    for ax in axes[:, 0]:
        ax.set_ylabel("z-normalised value")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTD, "fig_examples.png"))
    fig.savefig(os.path.join(OUTD, "fig_examples.pdf"))
    plt.close(fig)


def sweep():
    rows = [json.load(open(p)) for p in glob.glob(os.path.join(paths.SWEEP, "*.json"))]
    if not rows:
        return
    df = pd.DataFrame(rows)
    methods = ["Tikhonov", "GaussPrior", "LGD", "PostCNN", "DirectCNN", "Ridge"]
    long = df.melt(id_vars=["dataset", "task", "x"], value_vars=methods, var_name="method", value_name="nrmse")
    # error relative to Tikhonov at the same (dataset, task, N)
    tik = df.set_index(["dataset", "task", "x"])["Tikhonov"]
    long["ratio"] = long.nrmse.values / tik.loc[list(zip(long.dataset, long.task, long.x))].values
    agg = long.groupby(["task", "method", "x"]).ratio.apply(lambda s: float(np.exp(np.mean(np.log(s))))).reset_index()
    agg.to_csv(os.path.join(OUTD, "table_sweep.csv"), index=False)
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8), sharey=False)
    for ax, t in zip(axes, ["gaps", "deconv"]):
        for m in methods:
            a = agg[(agg.task == t) & (agg.method == m)].sort_values("x")
            ax.plot(a.x, a.ratio, "-o", ms=3.5, lw=1.6, color=COLOR[m], label=LABEL[m])
        ax.axhline(1, color=INK2, lw=0.8, ls="--")
        ax.set_xscale("log", base=2)
        ax.set_xticks([16, 32, 64, 128, 256, 512, 1024], ["16", "32", "64", "128", "256", "512", "1024"])
        ax.set_xlabel("Training series N")
        ax.set_title(TASK_LABEL[t], fontsize=9)
    axes[0].set_ylabel("Error relative to Tikhonov\n(geometric mean, 6 datasets)")
    axes[1].legend(fontsize=7, loc="upper right")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTD, "fig_sweep.png"))
    fig.savefig(os.path.join(OUTD, "fig_sweep.pdf"))
    plt.close(fig)
    print(agg.pivot_table(index=["task", "method"], columns="x", values="ratio").round(3).to_string())


def budget():
    rows = [json.load(open(p)) for p in glob.glob(os.path.join(paths.BUDGET, "*.json"))]
    if not rows:
        return
    df = pd.DataFrame(rows)
    out = []
    for t in ["gaps", "down"]:
        for m in ["LGD", "PostCNN", "DirectCNN"]:
            a = df[(df.task == t) & (df.x == 500)].set_index("dataset")[m]
            b = df[(df.task == t) & (df.x == 2000)].set_index("dataset")[m]
            idx = a.index.intersection(b.index)
            a, b = a.loc[idx], b.loc[idx]
            out.append(dict(task=t, method=m, n_datasets=len(idx), median_500=a.median(), median_2000=b.median(),
                            median_change_pct=float(np.median(100 * (b / a - 1))),
                            p_wilcoxon=float(stats.wilcoxon(a, b).pvalue) if len(idx) > 5 else np.nan))
    # ranks within each (dataset, task) at 500 vs 2000
    R = pd.DataFrame(out)
    rk = []
    for x in (500, 2000):
        d = df[df.x == x]
        for _, r in d.iterrows():
            v = np.array([r["LGD"], r["PostCNN"], r["DirectCNN"]])
            rk.append(dict(x=x, dataset=r.dataset, task=r.task, best=["LGD", "PostCNN", "DirectCNN"][int(np.argmin(v))]))
    rk = pd.DataFrame(rk).pivot_table(index=["dataset", "task"], columns="x", values="best", aggfunc="first")
    R.to_csv(os.path.join(OUTD, "table_budget.csv"), index=False)
    print(R.round(4).to_string())
    print("same best network at 500 and 2000 steps:", int((rk[500] == rk[2000]).sum()), "of", len(rk))


if __name__ == "__main__":
    examples()
    sweep()
    budget()
