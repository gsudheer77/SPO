"""Figure 9: decision guide. Box sizes are computed from the rendered text so labels never touch the borders."""
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from analysis import COLOR, INK, INK2

fig, ax = plt.subplots(figsize=(7.4, 4.9))
ax.set_xlim(0, 100); ax.set_ylim(0, 70); ax.axis("off")
fig.subplots_adjust(0.005, 0.005, 0.995, 0.995)
fig.canvas.draw()
R = fig.canvas.get_renderer()
PADX, PADY = 2.2, 1.6          # padding between text and box border, in data units
BOX = {}


def box(key, x, y, text, kind="q", color=None, dashed=False):
    t = ax.text(x, y, text, ha="center", va="center", fontsize=8.2 if kind == "q" else 7.6, color=INK,
                weight="bold" if kind != "q" else "normal", linespacing=1.25, zorder=3)
    bb = t.get_window_extent(renderer=R).transformed(ax.transData.inverted())
    w, h = bb.width + 2 * PADX, bb.height + 2 * PADY
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0,rounding_size=1.2",
                                fc="#f3f2ee" if kind == "q" else "white", ec=INK2 if kind == "q" else color,
                                lw=0.9 if kind == "q" else 1.5, ls=(0, (4, 2.5)) if dashed else "-", zorder=2))
    BOX[key] = (x, y, w, h)


def edge(a, b, label=None, lx=0, ly=0, fa=0.0, fb=0.0):
    """Arrow from the bottom of box a to the top of box b; fa/fb shift the endpoints horizontally (fraction of width)."""
    xa, ya, wa, ha = BOX[a]; xb, yb, wb, hb = BOX[b]
    x1, y1, x2, y2 = xa + fa * wa, ya - ha / 2, xb + fb * wb, yb + hb / 2
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color=INK2, lw=0.9, shrinkA=1, shrinkB=1), zorder=1)
    if label:
        ax.text((x1 + x2) / 2 + lx, (y1 + y2) / 2 + ly, label, fontsize=7.6, color=INK2, ha="center", va="center",
                bbox=dict(fc="white", ec="none", pad=0.8), zorder=4)


box("A", 50, 64, "Is the measurement operator A known?")
box("unk", 17, 49, "Fully learned network\n(not tested here; expected to lose\nmost if the sensor changes)", "a",
    COLOR["DirectCNN"], dashed=True)
box("vary", 64, 49, "Does A vary between series\nor change at deployment?")
box("unc", 37, 31.5, "Need uncertainty, or expect the\nmissingness pattern to shift?")
box("id", 84, 31.5, "Is A the identity?")
box("gp", 13, 12.5, "Learned Gaussian prior\n(best with many\nclean series)", "a", COLOR["GaussPrior"])
box("lgd", 37.5, 12.5, "Unrolled network\nusing A\n(LGD)", "a", COLOR["LGD"])
box("den", 62, 12.5, "Fully learned CNN\nor CNN\npost-processing", "a", COLOR["DirectCNN"])
box("pp", 87.5, 12.5, "CNN post-processing\nor unrolled network\nwith operator-based init", "a", COLOR["PostCNN"])

edge("A", "unk", "no", 0, 0.5, fa=-0.3)
edge("A", "vary", "yes", 2.5, 0, fa=0.25)
edge("vary", "unc", "yes (e.g. random gaps)", -5, 0.5, fa=-0.2)
edge("vary", "id", "no (fixed sensor)", 5.5, 0.5, fa=0.25)
edge("unc", "gp", "yes", -2.5, 0, fa=-0.25)
edge("unc", "lgd", "no: maximise\naccuracy", 5.5, 0, fa=0.1)
edge("id", "den", "yes", -2.5, 0, fa=-0.25)
edge("id", "pp", "no", 2.2, 0, fa=0.2)

ax.text(50, 2.2, "Baseline in every branch: bilevel-tuned Tikhonov (choose penalty order and strength on training pairs).\n"
        "Dashed box: practical guidance outside the benchmark, in which A was always known.",
        ha="center", va="center", fontsize=7.2, color=INK2, style="italic", linespacing=1.35)
import os, paths
for ext in ("png", "pdf", "svg"):
    fig.savefig(os.path.join(paths.OUT, f"fig_guide.{ext}"))
