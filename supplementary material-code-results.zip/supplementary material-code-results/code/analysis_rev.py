"""Tables and figures for the revision experiments (bench_rev.py A/B/C)."""
import os
import glob
import json
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from analysis import COLOR, LABEL, INK, INK2, GRID, OUTD, TASK_LABEL, holm, Q05

HERE = os.path.dirname(os.path.abspath(__file__))
import paths
REV = paths.REV
pd.set_option("display.width", 220)
VAR_LABEL = {"LGD": "A in init + loop", "LGD_noAloop": "A in init only", "LGD_noAinit": "A in loop only",
             "LGD_noA": "No A (init or loop)"}
VAR_COLOR = {"LGD": COLOR["LGD"], "LGD_noAloop": "#eda100", "LGD_noAinit": "#4a3aa7", "LGD_noA": COLOR["DirectCNN"]}
METH = ["Classical", "Tikhonov", "TV", "GaussPrior", "Ridge", "LGD", "PostCNN", "DirectCNN"]


def jl(mode):
    return [json.load(open(p)) for p in sorted(glob.glob(os.path.join(REV, mode, "*.json")))]


def wilcox(a, b):
    d = np.asarray(a) - np.asarray(b)
    return (int((d < 0).sum()), int((d > 0).sum()),
            float(stats.wilcoxon(a, b).pvalue) if np.any(d != 0) else 1.0,
            float(np.exp(np.mean(np.log(np.asarray(a) / np.asarray(b))))))


# ------------------------------------------------------------------ B: ablation
def ablation():
    B = jl("B")
    if not B:
        return
    print(f"B datasets: {len(B)}")
    rows, pair_rows = [], []
    for t in ["deconv", "gaps", "down"]:
        for cond in ["nrmse", "nrmse_mismatch", "nrmse_missing"]:
            recs = [dict(dataset=b["dataset"], **b["tasks"][t][cond]) for b in B if cond in b["tasks"][t]]
            if not recs:
                continue
            W = pd.DataFrame(recs).set_index("dataset")
            V = W[list(VAR_LABEL)]
            ranks = V.rank(axis=1).mean()
            chi2, pf = stats.friedmanchisquare(*[V[c] for c in V.columns])
            for v in VAR_LABEL:
                rows.append(dict(task=t, cond=cond, variant=v, avg_rank=ranks[v],
                                 gmean_ratio_vs_full=float(np.exp(np.mean(np.log(V[v] / V["LGD"])))),
                                 median=float(V[v].median()), friedman_p=pf, N=len(V)))
            comps = [("loop access | A-init", "LGD", "LGD_noAloop"), ("loop access | blind init", "LGD_noAinit", "LGD_noA"),
                     ("init access | A-loop", "LGD", "LGD_noAinit"), ("init access | blind loop", "LGD_noAloop", "LGD_noA"),
                     ("full vs none", "LGD", "LGD_noA")]
            for lab, a, b_ in comps:
                w1, w2, p, g = wilcox(V[a], V[b_])
                pair_rows.append(dict(task=t, cond=cond, comparison=lab, with_A=a, without_A=b_, with_better=w1,
                                      without_better=w2, gmean_ratio=g, p=p))
    R = pd.DataFrame(rows)
    P = pd.DataFrame(pair_rows)
    P["p_holm"] = np.nan
    for cond in P.cond.unique():
        m = P.cond == cond
        P.loc[m, "p_holm"] = holm(P.loc[m, "p"].values)
    R.to_csv(os.path.join(OUTD, "table_ablation_ranks.csv"), index=False)
    P.to_csv(os.path.join(OUTD, "table_ablation_pairs.csv"), index=False)
    print(R.round(4).to_string())
    print(P.round(5).to_string())

    # figure: geometric-mean error ratio vs full LGD, per task, nominal and mismatch
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.6), sharey=True)
    for ax, t in zip(axes, ["deconv", "gaps", "down"]):
        conds = ["nrmse", "nrmse_mismatch"] if t != "down" else ["nrmse"]
        for ci, cond in enumerate(conds):
            d = R[(R.task == t) & (R.cond == cond)].set_index("variant")
            ys = np.arange(4)
            for yi, v in enumerate(VAR_LABEL):
                x = d.loc[v, "gmean_ratio_vs_full"]
                ax.scatter(x, yi + (0.12 if ci else -0.12), s=28, marker="o" if ci == 0 else "D",
                           facecolor=VAR_COLOR[v] if ci == 0 else "white", edgecolor=VAR_COLOR[v], lw=1.3, zorder=3)
        ax.axvline(1, color=INK2, lw=0.8, ls="--")
        ax.set_yticks(range(4), [VAR_LABEL[v] for v in VAR_LABEL], fontsize=7)
        ax.set_title(TASK_LABEL[t].replace(" (4x)", ""), fontsize=9)
        ax.set_xlabel("Error / full LGD (geo. mean)", fontsize=7.5)
        ax.invert_yaxis()
        ax.grid(axis="y", visible=False)
    axes[0].scatter([], [], s=28, color=INK2, label="nominal operator")
    axes[0].scatter([], [], s=28, marker="D", facecolor="white", edgecolor=INK2, label="shifted operator (known)")
    fig.legend(*axes[0].get_legend_handles_labels(), loc="lower center", ncol=2, fontsize=7, bbox_to_anchor=(0.55, -0.08))
    fig.tight_layout()
    fig.savefig(os.path.join(OUTD, "fig_ablation.png"))
    fig.savefig(os.path.join(OUTD, "fig_ablation.pdf"))
    fig.savefig(os.path.join(OUTD, "fig_ablation.svg"))
    plt.close(fig)

    # paired absolute errors under mismatch (same 300 series)
    abs_rows = []
    for t in ["deconv", "gaps"]:
        W0 = pd.DataFrame([dict(dataset=b["dataset"], **b["tasks"][t]["nrmse"]) for b in B]).set_index("dataset")
        W1 = pd.DataFrame([dict(dataset=b["dataset"], **b["tasks"][t]["nrmse_mismatch"]) for b in B]).set_index("dataset")
        for m in METH:
            abs_rows.append(dict(task=t, method=m, median_nominal=float(W0[m].median()),
                                 median_mismatch=float(W1[m].median()),
                                 median_ratio=float(np.median(W1[m] / W0[m])),
                                 gmean_ratio=float(np.exp(np.mean(np.log(W1[m] / W0[m])))),
                                 rank_nominal=float(W0[METH].rank(axis=1).mean()[m]),
                                 rank_mismatch=float(W1[METH].rank(axis=1).mean()[m])))
    A = pd.DataFrame(abs_rows)
    A.to_csv(os.path.join(OUTD, "table_mismatch_paired.csv"), index=False)
    print(A.round(4).to_string())

    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9))
    for ax, t in zip(axes, ["deconv", "gaps"]):
        d = A[A.task == t].set_index("method").loc[[m for m in METH if m != "Classical" or t != "deconv"]]
        order = list(d.sort_values("median_mismatch", ascending=False).index)
        for yi, m in enumerate(order):
            ax.plot([d.loc[m, "median_nominal"], d.loc[m, "median_mismatch"]], [yi, yi], color=GRID, lw=3, zorder=1)
            ax.scatter(d.loc[m, "median_nominal"], yi, s=26, facecolor="white", edgecolor=COLOR[m], lw=1.4, zorder=2)
            ax.scatter(d.loc[m, "median_mismatch"], yi, s=30, color=COLOR[m], zorder=3)
            ax.text(d.loc[m, "median_mismatch"] + 0.004, yi, f"x{d.loc[m, 'median_ratio']:.2f}", fontsize=6.5,
                    color=INK2, va="center")
        ax.set_yticks(range(len(order)), [LABEL[m] for m in order], fontsize=7)
        ax.set_xlabel("Median NRMSE (same 300 test series)", fontsize=8)
        ax.set_title({"deconv": "Kernel 1.5x wider at test", "gaps": ">=50% missing at test (trained >=30%)"}[t], fontsize=9)
        ax.grid(axis="y", visible=False)
    axes[0].scatter([], [], s=26, facecolor="white", edgecolor=INK2, label="nominal")
    axes[0].scatter([], [], s=30, color=INK2, label="shifted (known)")
    fig.legend(*axes[0].get_legend_handles_labels(), loc="lower center", ncol=2, fontsize=7, bbox_to_anchor=(0.5, -0.06))
    fig.tight_layout()
    fig.savefig(os.path.join(OUTD, "fig_mismatch_abs.png"))
    fig.savefig(os.path.join(OUTD, "fig_mismatch_abs.pdf"))
    plt.close(fig)

    # architecture vs operator access: operator-free unrolled variant vs fully learned CNN, etc.
    arch = []
    for t in ["deconv", "gaps", "down"]:
        for cond in ["nrmse", "nrmse_mismatch", "nrmse_missing"]:
            if cond not in B[0]["tasks"][t]:
                continue
            W = pd.DataFrame([dict(dataset=b["dataset"], **b["tasks"][t][cond]) for b in B]).set_index("dataset")
            for a_, c_ in [("LGD_noA", "DirectCNN"), ("LGD", "DirectCNN"), ("GaussPrior", "LGD"), ("PostCNN", "DirectCNN")]:
                w = wilcox(W[a_], W[c_])
                arch.append(dict(task=t, cond=cond, a=a_, b=c_, a_better=w[0], b_better=w[1], p=w[2], gmean=w[3]))
    pd.DataFrame(arch).to_csv(os.path.join(OUTD, "table_ablation_arch.csv"), index=False)

    # missing-region errors (gap filling), all methods, 40 datasets
    Wm = pd.DataFrame([dict(dataset=b["dataset"], **b["tasks"]["gaps"]["nrmse_missing"]) for b in B]).set_index("dataset")
    Wf = pd.DataFrame([dict(dataset=b["dataset"], **b["tasks"]["gaps"]["nrmse"]) for b in B]).set_index("dataset")
    M = pd.DataFrame(dict(rank_missing=Wm[METH].rank(axis=1).mean(), median_missing=Wm[METH].median(),
                          rank_full=Wf[METH].rank(axis=1).mean(), median_full=Wf[METH].median()))
    M.to_csv(os.path.join(OUTD, "table_missing_region_B.csv"))
    print(M.round(4).to_string())
    w = wilcox(Wm["GaussPrior"], Wm["LGD"])
    print("missing-region GP vs LGD (GP better, LGD better, p, gmean):", w)
    w = wilcox(Wm["LGD"], Wm["DirectCNN"])
    print("missing-region LGD vs Direct:", w)
    print("B train_s median:", pd.DataFrame([b["tasks"][t]["train_s"] for b in B for t in ["deconv", "gaps", "down"]]).median().round(1).to_dict())


# ------------------------------------------------------------------ A
def part_A():
    A = jl("A")
    if not A:
        return
    print(f"A datasets: {len(A)}")
    tune = []
    for a in A:
        for t, r in a["tasks"].items():
            tune.append(dict(dataset=a["dataset"], task=t, n_train=a["n_train"], tik_first=r["tik_first"],
                             tik_random=r["tik_random"], tv_first=r["tv_first"], tv_random=r["tv_random"],
                             tik_changed=r["tik_first_par"] != r["tik_random_par"],
                             tv_changed=r["tv_first_par"] != r["tv_random_par"]))
    T = pd.DataFrame(tune)
    T.to_csv(os.path.join(OUTD, "table_tuning_order_raw.csv"), index=False)
    summ = []
    for t in ["denoise", "deconv", "gaps", "down"]:
        d = T[(T.task == t) & (T.n_train > 200)]
        for m in ["tik", "tv"]:
            ratio = d[f"{m}_random"] / d[f"{m}_first"]
            w = wilcox(d[f"{m}_random"], d[f"{m}_first"])
            summ.append(dict(task=t, method=m, n_affected=len(d), n_param_changed=int(d[f"{m}_changed"].sum()),
                             median_ratio_random_over_first=float(ratio.median()),
                             max_abs_change_pct=float(100 * np.max(np.abs(ratio - 1))),
                             random_better=w[0], first_better=w[1], p=w[2]))
    S = pd.DataFrame(summ)
    S.to_csv(os.path.join(OUTD, "table_tuning_order.csv"), index=False)
    print(S.round(4).to_string())

    # coverage curve
    cov = []
    for a in A:
        for t, r in a["tasks"].items():
            for lev, c in r["coverage"].items():
                cov.append(dict(dataset=a["dataset"], task=t, level=float(lev), coverage=c, where="all"))
            if "coverage_missing" in r:
                for lev, c in r["coverage_missing"].items():
                    cov.append(dict(dataset=a["dataset"], task=t, level=float(lev), coverage=c, where="missing"))
    C = pd.DataFrame(cov)
    Cs = C.groupby(["task", "where", "level"]).coverage.describe(percentiles=[.1, .5, .9]).reset_index()
    Cs.to_csv(os.path.join(OUTD, "table_coverage_curve.csv"), index=False)
    print(Cs[["task", "where", "level", "10%", "50%", "90%"]].round(3).to_string())

    fig, axes = plt.subplots(1, 4, figsize=(7.2, 2.3), sharey=True)
    for ax, t in zip(axes, ["denoise", "deconv", "gaps", "down"]):
        d = Cs[(Cs.task == t) & (Cs["where"] == "all")]
        ax.fill_between(d.level * 100, d["10%"] * 100, d["90%"] * 100, color="#cfe0f6", lw=0, label="10th-90th pct. of datasets")
        ax.plot(d.level * 100, d["50%"] * 100, "-o", ms=3, color=COLOR["GaussPrior"], lw=1.6, label="median over datasets")
        if t == "gaps":
            dm = Cs[(Cs.task == t) & (Cs["where"] == "missing")]
            ax.plot(dm.level * 100, dm["50%"] * 100, "--", color=COLOR["GaussPrior"], lw=1.2, label="median, missing points only")
        ax.plot([0, 100], [0, 100], color=INK2, lw=0.8, ls=":")
        ax.set_xlim(0, 100)
        ax.set_ylim(0, 100)
        ax.set_title(TASK_LABEL[t].replace(" (4x)", ""), fontsize=9)
        ax.set_xlabel("Nominal level (%)", fontsize=8)
        ax.set_aspect("equal")
    axes[0].set_ylabel("Empirical coverage (%)")
    h, l = axes[2].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=3, fontsize=7, bbox_to_anchor=(0.5, -0.12))
    fig.tight_layout()
    fig.savefig(os.path.join(OUTD, "fig_coverage_curve.png"))
    fig.savefig(os.path.join(OUTD, "fig_coverage_curve.pdf"))
    plt.close(fig)

    # missing-region errors, closed-form methods, all datasets
    mr = pd.DataFrame([dict(dataset=a["dataset"], Classical=a["tasks"]["gaps"]["classical_missing"],
                            Tikhonov=a["tasks"]["gaps"]["tik_missing"], TV=a["tasks"]["gaps"]["tv_missing"],
                            GaussPrior=a["tasks"]["gaps"]["gp_missing"], missing_frac=a["tasks"]["gaps"]["missing_frac"])
                       for a in A]).set_index("dataset")
    mr.describe().to_csv(os.path.join(OUTD, "table_missing_region_A.csv"))
    print(mr.median().round(4).to_dict())
    print("GP vs Tik missing-region:", wilcox(mr.GaussPrior, mr.Tikhonov))


# ------------------------------------------------------------------ C
def part_C():
    C = pd.DataFrame(jl("C"))
    if C.empty:
        return
    for m in ["GaussPrior", "LGD", "DirectCNN"]:
        C[f"{m}_ratio"] = C[m] / C["Tikhonov"]
    g = C.groupby(["N", "seed"])[[f"{m}_ratio" for m in ["GaussPrior", "LGD", "DirectCNN"]]].apply(
        lambda d: np.exp(np.log(d).mean()))
    summ = g.groupby("N").agg(["mean", "std", "min", "max"])
    summ.to_csv(os.path.join(OUTD, "table_sweep_seeds.csv"))
    print(summ.round(3).to_string())
    # per-dataset seed spread
    sp = C.groupby(["dataset", "N"])[["GaussPrior_ratio", "LGD_ratio", "DirectCNN_ratio"]].std().groupby("N").median()
    sp.to_csv(os.path.join(OUTD, "table_sweep_seed_spread.csv"))
    print("median within-dataset SD across seeds:\n", sp.round(3).to_string())
    # how often each method beats Tikhonov at each N (over dataset x seed)
    beat = C.groupby("N")[["GaussPrior_ratio", "LGD_ratio", "DirectCNN_ratio"]].apply(lambda d: (d < 1).mean())
    print("share of runs beating Tikhonov:\n", beat.round(3).to_string())
    beat.to_csv(os.path.join(OUTD, "table_sweep_seeds_beat.csv"))


if __name__ == "__main__":
    ablation()
    part_A()
    part_C()
