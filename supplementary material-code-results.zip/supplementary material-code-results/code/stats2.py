import pandas as pd, numpy as np
from scipy import stats
from analysis import load, holm
from constants import TASKS, METHODS
df, meta = load()
out=[]
pairs=[("LGD","DirectCNN"),("PostCNN","DirectCNN"),("GaussPrior","Ridge"),("LGD","PostCNN"),("GaussPrior","LGD"),("GaussPrior","Tikhonov"),("TV","Tikhonov")]
for t in TASKS:
    W=df[df.task==t].pivot(index="dataset",columns="method",values="nrmse")
    for a,b in pairs:
        d=W[a]-W[b]
        p=stats.wilcoxon(W[a],W[b]).pvalue
        out.append(dict(task=t,a=a,b=b,a_better=int((d<0).sum()),b_better=int((d>0).sum()),
                        median_ratio=float(np.median(W[a]/W[b])),p=p))
R=pd.DataFrame(out); R["p_holm"]=holm(R.p.values)
import os, paths
R.to_csv(os.path.join(paths.OUT, "table_pairs.csv"),index=False); print(R.round(4).to_string())
# mismatch ratios
for t in ["deconv","gaps"]:
    d=df[df.task==t]
    print(t,"mismatch median ratio (mismatch/main):",{m: round(float(np.median(d[d.method==m].nrmse_mismatch/d[d.method==m].nrmse)),3) for m in METHODS})
    W=d.pivot(index="dataset",columns="method",values="nrmse_mismatch")
    avg=W[METHODS].rank(axis=1).mean(); print(" mismatch avg ranks", avg.round(2).to_dict())
for s in ["nrmse_sigma0.05","nrmse_sigma0.2"]:
    for t in TASKS:
        W=df[df.task==t].pivot(index="dataset",columns="method",values=s)[METHODS]
        print(s,t,"avg rank", W.rank(axis=1).mean().round(2).to_dict())
# lambda order chosen
import json,glob
orders={t:[] for t in TASKS}
for p in glob.glob(os.path.join(paths.MAIN, "*.json")):
    r=json.load(open(p))
    for t in TASKS: orders[t].append(r["tasks"][t]["Tikhonov"]["lambda"][1])
print({t:(np.array(v)==1).mean().round(3) for t,v in orders.items()}, "share order 1")
print(meta.describe().round(1).to_string())
print("n resampled", (meta.n_orig>256).sum(), "n_train<100", (meta.n_train<100).sum(), "median n_train", meta.n_train.median())
cal=df[df.method=="GaussPrior"].groupby("task")[["coverage90","coverage50","width90"]].agg(["median",lambda s: s.quantile(.1),lambda s: s.quantile(.9)])
print(cal.round(3))
print(df.groupby(["task","method"]).acc.median().unstack().round(3))
print("clean acc median", meta.acc_clean.median())
acc=df.assign(drop=df.acc_clean-df.acc).groupby(["task","method"])["drop"].mean().unstack().round(4); print(acc)
print(df.groupby("method")[["train_s","infer_s_per_series"]].median())
print(df.groupby("method").params.median())
print("total wall h", meta.wall_s.sum()/3600)
