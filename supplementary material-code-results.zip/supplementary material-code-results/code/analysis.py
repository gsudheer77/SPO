"""Statistics, tables and figures for the UCR inverse-problem benchmark.

Usage: python analysis.py   (reads ../results/per_dataset, writes ../results/tables)
"""
import os
import glob
import json
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from constants import METHODS, TASKS

HERE = os.path.dirname(os.path.abspath(__file__))
import paths
OUTD = paths.OUT
os.makedirs(OUTD, exist_ok=True)

TASK_LABEL = {"denoise": "Denoising", "deconv": "Deconvolution", "gaps": "Gap filling", "down": "Downsampling (4x)"}
LABEL = {"Classical": "Classical", "Tikhonov": "Tikhonov", "TV": "TV", "GaussPrior": "Learned Gaussian prior",
         "LGD": "Unrolled LGD", "PostCNN": "CNN post-processing", "DirectCNN": "Fully learned CNN", "Ridge": "Ridge map"}
FAMILY = {"Classical": "Knowledge-driven", "Tikhonov": "Knowledge-driven", "TV": "Knowledge-driven",
          "GaussPrior": "Hybrid (uses A)", "LGD": "Hybrid (uses A)", "PostCNN": "Hybrid (uses A)",
          "DirectCNN": "Data-driven (no A)", "Ridge": "Data-driven (no A)"}
# fixed colour per method (reference categorical palette, light mode); never re-assigned
COLOR = {"GaussPrior": "#2a78d6", "LGD": "#eb6834", "DirectCNN": "#1baf7a", "PostCNN": "#eda100",
         "Ridge": "#e87ba4", "TV": "#008300", "Tikhonov": "#4a3aa7", "Classical": "#8a8984"}
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2,
                     "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.color": GRID, "grid.linewidth": 0.6, "legend.frameon": False,
                     "savefig.dpi": 300, "savefig.bbox": "tight"})

# Nemenyi critical values q_0.05 (Demsar 2006, Table 5), k = 2..10
Q05 = {2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728, 6: 2.850, 7: 2.949, 8: 3.031, 9: 3.102, 10: 3.164}


def load():
    rows, meta = [], []
    for p in sorted(glob.glob(os.path.join(paths.MAIN, "*.json"))):
        r = json.load(open(p))
        meta.append({k: r[k] for k in ("dataset", "n_orig", "n", "n_train", "n_test", "n_classes", "acc_clean", "wall_s")})
        for t, tr in r["tasks"].items():
            for m, v in tr.items():
                rows.append(dict(dataset=r["dataset"], task=t, method=m, n_train=r["n_train"], n=r["n"],
                                 acc_clean=r["acc_clean"], **v))
    return pd.DataFrame(rows), pd.DataFrame(meta)


def holm(p):
    p = np.asarray(p)
    order = np.argsort(p)
    adj = np.empty_like(p)
    running = 0
    for i, j in enumerate(order):
        running = max(running, min(1, (len(p) - i) * p[j]))
        adj[j] = running
    return adj


def friedman_block(W):
    """W: datasets x methods error matrix. Returns avg ranks, chi2, p, Iman-Davenport F, p_F, CD."""
    N, k = W.shape
    R = np.apply_along_axis(stats.rankdata, 1, W)
    avg = R.mean(0)
    chi2 = 12 * N / (k * (k + 1)) * (np.sum(avg ** 2) - k * (k + 1) ** 2 / 4)
    p = stats.chi2.sf(chi2, k - 1)
    F = (N - 1) * chi2 / (N * (k - 1) - chi2)
    pF = stats.f.sf(F, k - 1, (k - 1) * (N - 1))
    cd = Q05[k] * np.sqrt(k * (k + 1) / (6 * N))
    return avg, chi2, p, F, pF, cd


def cd_diagram(ax, names, avg, cd, title):
    order = np.argsort(avg)
    k = len(names)
    lo, hi = 1, k
    ax.set_xlim(hi + 2.6, lo - 2.6)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.hlines(0.8, lo, hi, color=INK2, lw=0.8)
    for x in range(lo, hi + 1):
        ax.vlines(x, 0.8, 0.84, color=INK2, lw=0.8)
        ax.text(x, 0.87, str(x), ha="center", va="bottom", fontsize=7, color=INK2)
    ax.text((lo + hi) / 2, 1.0, title, ha="center", va="bottom", fontsize=9, color=INK, weight="bold")
    # CD bar
    ax.hlines(0.95, lo, lo + cd, color=INK, lw=1.4)
    ax.text(lo + cd / 2, 0.955, f"CD = {cd:.2f}", ha="center", va="bottom", fontsize=7, color=INK)
    half = int(np.ceil(k / 2))
    for i, j in enumerate(order):
        x = avg[j]
        if i < half:
            y = 0.62 - 0.1 * i
            ax.plot([x, x, lo - 0.2], [0.8, y, y], color=COLOR[names[j]], lw=1.2)
            ax.text(lo - 0.25, y, f"{LABEL[names[j]]} ({x:.2f})", ha="left", va="center", fontsize=7, color=INK)
        else:
            y = 0.62 - 0.1 * (k - 1 - i)
            ax.plot([x, x, hi + 0.2], [0.8, y, y], color=COLOR[names[j]], lw=1.2)
            ax.text(hi + 0.25, y, f"({x:.2f}) {LABEL[names[j]]}", ha="right", va="center", fontsize=7, color=INK)
    # cliques: maximal groups of consecutive methods within CD
    s = avg[order]
    cliques = []
    for a in range(k):
        b = a
        while b + 1 < k and s[b + 1] - s[a] <= cd:
            b += 1
        if b > a and not any(c[0] <= a and b <= c[1] for c in cliques):
            cliques.append((a, b))
    for i, (a, b) in enumerate(cliques):
        y = 0.74 - 0.035 * i
        ax.hlines(y, s[a] - 0.03, s[b] + 0.03, color=INK, lw=2.2)


def main():
    df, meta = load()
    Nd = meta.dataset.nunique()
    print(f"datasets: {Nd}")
    lines = []
    summary = []
    stat_rows = []
    fig, axes = plt.subplots(4, 1, figsize=(7.2, 7.6))
    for ai, t in enumerate(TASKS):
        W = df[df.task == t].pivot(index="dataset", columns="method", values="nrmse")[METHODS].dropna()
        avg, chi2, p, F, pF, cd = friedman_block(W.values)
        stat_rows.append(dict(task=t, N=len(W), chi2=chi2, p=p, F_ID=F, p_ID=pF, CD=cd))
        best = METHODS[int(np.argmin(avg))]
        # Wilcoxon signed-rank best vs others, Holm-adjusted
        ps, others = [], [m for m in METHODS if m != best]
        for m in others:
            d = W[m] - W[best]
            ps.append(stats.wilcoxon(W[best], W[m]).pvalue if np.any(d != 0) else 1.0)
        padj = dict(zip(others, holm(ps)))
        tik = W["Tikhonov"]
        for j, m in enumerate(METHODS):
            ratio = W[m] / tik
            wins = int(np.sum(W[m].values < W.drop(columns=[m]).min(axis=1).values))
            summary.append(dict(task=t, method=m, avg_rank=avg[j], median_nrmse=W[m].median(),
                                gmean_ratio_vs_tik=float(np.exp(np.mean(np.log(ratio)))),
                                wins=wins, better_than_tik=int(np.sum(W[m] < tik)),
                                p_holm_vs_best=padj.get(m, np.nan), best=(m == best)))
        cd_diagram(axes[ai], METHODS, avg, cd, TASK_LABEL[t])
    fig.savefig(os.path.join(OUTD, "fig_cd.png"))
    fig.savefig(os.path.join(OUTD, "fig_cd.pdf"))
    fig.savefig(os.path.join(OUTD, "fig_cd.svg"))
    plt.close(fig)
    S = pd.DataFrame(summary)
    S.to_csv(os.path.join(OUTD, "table_main.csv"), index=False)
    pd.DataFrame(stat_rows).to_csv(os.path.join(OUTD, "table_friedman.csv"), index=False)
    print(pd.DataFrame(stat_rows).round(4).to_string())
    print(S.round(4).to_string())

    # ---------------- improvement over Tikhonov vs training-set size (binned medians)
    bins = [0, 50, 150, 500, 10 ** 6]
    blab = ["<50", "50-149", "150-499", ">=500"]
    fig, axes = plt.subplots(1, 4, figsize=(7.2, 2.5), sharey=True)
    reg_rows, bin_rows = [], []
    for ai, t in enumerate(TASKS):
        W = df[df.task == t].pivot(index="dataset", columns="method", values="nrmse")
        ntr = df[df.task == t].groupby("dataset").n_train.first().loc[W.index]
        cat = pd.cut(ntr, bins, right=False, labels=blab)
        ax = axes[ai]
        for m in ["GaussPrior", "LGD", "DirectCNN"]:
            y = 100 * (1 - W[m] / W["Tikhonov"])
            rho, pr = stats.spearmanr(np.log(ntr), y)
            reg_rows.append(dict(task=t, method=m, spearman_rho=rho, p=pr, median_gain_pct=float(np.median(y))))
            med = y.groupby(cat, observed=False).median()
            q1 = y.groupby(cat, observed=False).quantile(0.25)
            q3 = y.groupby(cat, observed=False).quantile(0.75)
            xs = np.arange(len(blab)) + {"GaussPrior": -0.15, "LGD": 0, "DirectCNN": 0.15}[m]
            ax.errorbar(xs, med.values, yerr=[med.values - q1.values, q3.values - med.values], fmt="o-", ms=4,
                        lw=1.4, elinewidth=0.9, capsize=0, color=COLOR[m], label=LABEL[m])
            for bl, v in zip(blab, med.values):
                bin_rows.append(dict(task=t, method=m, bin=bl, median_gain_pct=float(v),
                                     n_datasets=int((cat == bl).sum())))
        ax.axhline(0, color=INK2, lw=0.8)
        ax.set_xticks(range(len(blab)), blab, fontsize=7, rotation=30)
        ax.set_title(TASK_LABEL[t], fontsize=9)
        ax.set_xlabel("Training series", fontsize=8)
    axes[0].set_ylabel("Error reduction vs\nTikhonov (%, median, IQR)")
    fig.legend(*axes[0].get_legend_handles_labels(), loc="lower center", ncol=3, fontsize=7, bbox_to_anchor=(0.5, -0.1))
    fig.tight_layout()
    fig.savefig(os.path.join(OUTD, "fig_trainsize.png"))
    fig.savefig(os.path.join(OUTD, "fig_trainsize.pdf"))
    plt.close(fig)
    R = pd.DataFrame(reg_rows)
    R.to_csv(os.path.join(OUTD, "table_trainsize.csv"), index=False)
    pd.DataFrame(bin_rows).to_csv(os.path.join(OUTD, "table_trainsize_bins.csv"), index=False)
    print(R.round(3).to_string())

    # ---------------- robustness (relative change of error, median across datasets)
    rob = []
    for t in TASKS:
        d = df[df.task == t]
        for m in METHODS:
            x = d[d.method == m]
            row = dict(task=t, method=m)
            for col, lab in [("nrmse_sigma0.05", "sigma_0.05"), ("nrmse_sigma0.2", "sigma_0.2"), ("nrmse_mismatch", "operator")]:
                if col in x and x[col].notna().any():
                    row[lab] = float(x[col].median())
            rob.append(row)
    RB = pd.DataFrame(rob)
    RB.to_csv(os.path.join(OUTD, "table_robust.csv"), index=False)
    print(RB.round(3).to_string())

    # mismatch figure: average rank under the matched operator vs under operator mismatch
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9), sharex=True)
    for ai, t in enumerate(["deconv", "gaps"]):
        d = df[df.task == t]
        r0 = d.pivot(index="dataset", columns="method", values="nrmse")[METHODS].rank(axis=1).mean()
        r1 = d.pivot(index="dataset", columns="method", values="nrmse_mismatch")[METHODS].rank(axis=1).mean()
        order = list(r1.sort_values(ascending=False).index)
        ax = axes[ai]
        for yi, m in enumerate(order):
            ax.plot([r0[m], r1[m]], [yi, yi], color=GRID, lw=3, solid_capstyle="round", zorder=1)
            ax.scatter([r0[m]], [yi], s=26, facecolor="white", edgecolor=COLOR[m], lw=1.4, zorder=2)
            ax.scatter([r1[m]], [yi], s=30, color=COLOR[m], zorder=3)
        ax.set_yticks(range(len(order)), [LABEL[m] for m in order], fontsize=7)
        ax.set_xlim(8.3, 0.7)
        ax.set_xlabel("Average rank (1 = best)")
        ax.set_title({"deconv": "Kernel 1.5x wider at test", "gaps": "50% missing at test (trained on 30%)"}[t], fontsize=9)
        ax.grid(axis="y", visible=False)
    axes[0].scatter([], [], s=26, facecolor="white", edgecolor=INK2, label="nominal operator")
    axes[0].scatter([], [], s=30, color=INK2, label="shifted operator (known)")
    axes[0].legend(fontsize=7, loc="lower left")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTD, "fig_mismatch.png"))
    fig.savefig(os.path.join(OUTD, "fig_mismatch.pdf"))
    plt.close(fig)

    # ---------------- calibration of the Gaussian prior
    g = df[df.method == "GaussPrior"]
    cal = g.groupby("task")[["coverage90", "coverage50", "width90"]].describe(percentiles=[.1, .5, .9])
    cal.to_csv(os.path.join(OUTD, "table_calibration.csv"))
    fig, ax = plt.subplots(figsize=(3.5, 2.4))
    data = [g[g.task == t].coverage90.values * 100 for t in TASKS]
    bp = ax.boxplot(data, widths=0.5, patch_artist=True, showfliers=True,
                    flierprops=dict(marker="o", ms=3, mfc=COLOR["GaussPrior"], mec="none", alpha=0.6),
                    medianprops=dict(color=INK, lw=1.2))
    for b in bp["boxes"]:
        b.set(facecolor="#cfe0f6", edgecolor=COLOR["GaussPrior"])
    ax.axhline(90, color=INK2, lw=0.8, ls="--")
    ax.text(0.55, 90.4, "nominal 90%", fontsize=7, color=INK2, ha="left", va="bottom")
    ax.set_xticks(range(1, 5), [TASK_LABEL[t].replace(" (4x)", "") for t in TASKS], fontsize=7)
    ax.set_ylabel("Empirical coverage (%)")
    fig.savefig(os.path.join(OUTD, "fig_calibration.png"))
    fig.savefig(os.path.join(OUTD, "fig_calibration.pdf"))
    plt.close(fig)
    print(g.groupby("task")[["coverage90", "coverage50"]].median())

    # ---------------- downstream 1-NN accuracy retention
    acc = df.copy()
    acc["retention"] = acc.acc / acc.acc_clean
    A = acc.groupby(["task", "method"]).agg(median_acc=("acc", "median"), median_retention=("retention", "median"),
                                             mean_drop=("acc", lambda s: np.nan)).reset_index()
    drop = acc.assign(drop=acc.acc_clean - acc.acc).groupby(["task", "method"])["drop"].mean().reset_index()
    A = A.drop(columns="mean_drop").merge(drop, on=["task", "method"])
    A.to_csv(os.path.join(OUTD, "table_accuracy.csv"), index=False)
    print(A.round(4).to_string())
    print("median clean 1-NN acc", meta.acc_clean.median())

    # ---------------- runtime
    T = df.groupby("method")[["train_s", "infer_s_per_series"]].median()
    T.to_csv(os.path.join(OUTD, "table_runtime.csv"))
    print(T)
    meta.to_csv(os.path.join(OUTD, "datasets.csv"), index=False)


if __name__ == "__main__":
    main()
