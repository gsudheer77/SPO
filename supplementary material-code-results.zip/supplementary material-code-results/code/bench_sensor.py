"""First-order sensor study and per-iteration diagnostic (optional; prepared after the pre-submission review).

    python bench_sensor.py <worker_id> <n_workers> [datasets]      # datasets: comma-separated list or "all"

Not yet run for the manuscript. Needs the UCR data and PyTorch, like bench_sp.py; results go to results/sp/S/.

Operator. A sensor with time constant tau (in samples) obeys tau dz/dt + z = x. For a piecewise-constant input the
exact discretisation is z_k = a z_(k-1) + (1 - a) x_k with a = exp(-1/tau), started at steady state (z_(-1) = x_0).
The operator is lower triangular with rows summing to one. Unlike the symmetric Gaussian kernel of the main study it
is causal (it delays the signal) and only mildly ill-conditioned (condition number about 13 at tau = 4, against
about 2e14 for the Gaussian kernel), so the two operators bracket very different singular-value spectra.
The nominal time constant is tau0 = n/64 samples (4 for n = 256), the scale of the Gaussian kernel width.

Conditions. Every method is tuned / trained once at tau0 (Suite of bench_sp.py with the ablation variants and PnP).
  known          true tau = c tau0, c in WIDTHS, supplied to operator-based methods
  supplied_err   true tau = 1.5 tau0, supplied as 1.5 (1 +- 0.1) tau0
  drift          true tau = (1 + d) tau0, d in MISSPEC, methods are given tau0
Per-iteration diagnostic (answers "does the initial estimate carry the gain?"): NRMSE of the initial estimate and
after each of the K = 4 unrolled iterations, for LGD (A in init and loop), LGD_noAinit (A in loop only) and LGD_noA,
at the nominal operator, the known changes 0.5x, 1.5x, 2x and a 20 % drift that is not supplied. The same diagnostic
is recorded for the Gaussian deconvolution operator of the main study (key 'gauss'), so the two operators can be compared.

Seeds depend only on the dataset name, as in bench_sp.py.
"""
import os
import sys
import json
import time
import zlib

import numpy as np
import torch

import paths
import bench
import bench_sp as SP
from bench import rmse, tikhonov_matrix, x0_estimate, TorchOp
from bench_rev import predict_generic, make_init
from bench_sp import SIG, WIDTHS, MISSPEC, Suite, load, scores, train_denoiser, deconv_op

RES = os.path.join(paths.RESULTS, "sp")
DIAG = {"nominal": 1.0, "known 0.5": 0.5, "known 1.5": 1.5, "known 2.0": 2.0}


def sensor_matrix(n, tau):
    a = np.exp(-1.0 / tau)
    A = np.zeros((n, n))
    for i in range(n):
        A[i, :i + 1] = (1 - a) * a ** (i - np.arange(i + 1))
        A[i, 0] += a ** (i + 1)                     # steady-state start z_(-1) = x_0
    return A


def sensor_op(n, factor=1.0):
    op = bench.Op("deconv", n, width=1.0)           # a fixed linear operator; only op.A is used by the methods
    op.A = sensor_matrix(n, max(1.0, n / 64) * factor)
    return op


def make_suite(Ftr_all, seed, nominal_op_fn, den):
    """Suite of bench_sp.py trained at the given nominal operator (bench_sp.make_op is swapped temporarily)."""
    orig = SP.make_op
    SP.make_op = lambda kind, n, cfg, variant="main": nominal_op_fn(n, 1.0)
    try:
        return Suite("deconv", Ftr_all, seed, ablation=True, denoiser=den, cheap=True)
    finally:
        SP.make_op = orig


def iterates(net, op, G, x0, loop_A=True):
    """NRMSE-ready iterates f^0..f^K of an unrolled network (bench.LGD or bench_rev.LGDAblate)."""
    top = TorchOp(op)
    t = lambda a: torch.tensor(a, dtype=torch.float32)
    gup, Gt, f = t(op.upsample(G)), t(G), t(x0)
    out = [f.numpy().copy()]
    with torch.no_grad():
        for blk in net.blocks:
            grad = top.adj(top.fwd(f, None) - Gt, None) if loop_A else f - gup
            f = f + blk(torch.stack([f, grad], 1))[:, 0]
            out.append(f.numpy().copy())
    return out


def diagnostic(S, op_true, op_assumed, Fte, rng):
    G, _ = op_true.measure(Fte, SIG, rng)
    tikR = tikhonov_matrix(op_assumed, S.lam)
    res = {}
    res["LGD"] = iterates(S.nets["LGD"], op_assumed, G, x0_estimate(op_assumed, G, None, tikR), True)
    for v, (net, blind) in S.abl.items():
        x0 = op_assumed.upsample(G) if blind else x0_estimate(op_assumed, G, None, tikR)
        res[v] = iterates(net, op_assumed, G, x0, net.loop_A)
    return {k: [float(rmse(f, Fte).mean()) for f in v] for k, v in res.items()}


def study(Ftr_all, Fte, seed, op_fn, den, full=True):
    n = Ftr_all.shape[1]
    S = make_suite(Ftr_all, seed, op_fn, den)
    nom = op_fn(n, 1.0)
    out = dict(known={}, supplied_err={}, drift={}, iterates={})
    G, _ = nom.measure(Fte, SIG, np.random.default_rng(seed + 11))
    out["nominal"] = scores(S.predict(nom, G, None), Fte)
    for c in (WIDTHS if full else ()):
        op = op_fn(n, c)
        G, _ = op.measure(Fte, SIG, np.random.default_rng(seed + 13))
        out["known"][str(c)] = scores(S.predict(op, G, None), Fte)
    for d in ((-0.1, 0.1) if full else ()):
        op = op_fn(n, 1.5)
        G, _ = op.measure(Fte, SIG, np.random.default_rng(seed + 19))
        out["supplied_err"][str(d)] = scores(S.predict(op, G, None, assumed_op=op_fn(n, 1.5 * (1 + d))), Fte)
    for d in (MISSPEC if full else ()):
        op = op_fn(n, 1 + d)
        G, _ = op.measure(Fte, SIG, np.random.default_rng(seed + 17))
        out["drift"][str(d)] = scores(S.predict(op, G, None, assumed_op=nom), Fte)
    for lab, c in DIAG.items():
        out["iterates"][lab] = diagnostic(S, op_fn(n, c), op_fn(n, c), Fte, np.random.default_rng(seed + 23))
    out["iterates"]["drift 0.2 (not supplied)"] = diagnostic(S, op_fn(n, 1.2), nom, Fte, np.random.default_rng(seed + 29))
    sv = np.linalg.svd(nom.A, compute_uv=False)
    out["cond_nominal"] = float(sv[0] / sv[-1])
    return out


def run_S(name):
    seed = zlib.crc32(("S" + name).encode()) % (2 ** 31)
    Ftr_all, Fte, _ = load(name, np.random.default_rng(seed))
    den = train_denoiser(Ftr_all, np.random.default_rng(seed + 41), 1000)
    return dict(dataset=name, n=Ftr_all.shape[1],
                sensor=study(Ftr_all, Fte, seed, sensor_op, den),
                gauss=study(Ftr_all, Fte, seed, deconv_op, den, full=False))


def main():
    torch.set_num_threads(1)
    wid, nw = int(sys.argv[1]), int(sys.argv[2])
    sel = sys.argv[3] if len(sys.argv) > 3 else None
    names = SP.SP_SETS if sel is None else (bench.usable() if sel == "all" else sel.split(","))
    od = os.path.join(RES, "S")
    os.makedirs(od, exist_ok=True)
    for i, name in enumerate(names):
        if i % nw != wid:
            continue
        path = os.path.join(od, f"{name}.json")
        if os.path.exists(path):
            continue
        t0 = time.time()
        try:
            res = run_S(name)
            res["wall_s"] = time.time() - t0
            json.dump(res, open(path, "w"))
            print("S", name, f"{time.time() - t0:.0f}s", flush=True)
        except Exception as exc:
            import traceback
            traceback.print_exc()
            print("S", name, "FAILED", repr(exc), flush=True)


if __name__ == "__main__":
    main()
