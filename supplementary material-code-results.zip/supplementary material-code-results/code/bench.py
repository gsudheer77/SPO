"""Benchmark of knowledge-driven, hybrid and data-driven reconstruction methods
for time series inverse problems on the UCR archive.

Usage:  python bench.py <worker_id> <n_workers>        (results -> ../results/per_dataset/<dataset>.json)
"""
import os
import sys
import json
import time
import zlib
import numpy as np
import scipy.linalg as sla
from sklearn.covariance import LedoitWolf
import torch
import torch.nn as nn

import ucr_io

CFG = dict(sigma=0.1, max_len=256, max_train=2000, max_test=1000, robust_test=300,
           gap_rate=0.3, ds_factor=4, steps=500, batch=32, lr=2e-3, eval_every=100,
           tik_grid=np.logspace(-4, 3, 15).tolist(), tv_grid=np.logspace(-3, 1, 9).tolist(),
           tune_n=200, admm_iters=200, admm_tune_iters=100, rho=1.0, lgd_K=4, hidden=32)
TASKS = ["denoise", "deconv", "gaps", "down"]
METHODS = ["Classical", "Tikhonov", "TV", "GaussPrior", "LGD", "PostCNN", "DirectCNN", "Ridge"]
import paths
OUT = paths.MAIN


# ============================================================ data
def prep(X, max_len):
    X = np.asarray(X, float)
    n = X.shape[1]
    if n > max_len:
        t_old, t_new = np.linspace(0, 1, n), np.linspace(0, 1, max_len)
        X = np.vstack([np.interp(t_new, t_old, x) for x in X])
    mu, sd = X.mean(1, keepdims=True), X.std(1, keepdims=True)
    sd[sd < 1e-8] = 1.0
    return (X - mu) / sd


# ============================================================ forward operators
def diff1(n):
    return (np.eye(n, k=1) - np.eye(n))[:-1]


def diff2(n):
    return diff1(n - 1) @ diff1(n)


def conv_matrix(n, width):
    half = int(np.ceil(4 * width))
    k = np.exp(-0.5 * (np.arange(-half, half + 1) / width) ** 2)
    k /= k.sum()
    A = np.zeros((n, n))
    for i in range(n):
        for j, kv in zip(range(i - half, i + half + 1), k):
            A[i, min(max(j, 0), n - 1)] += kv
    return A


def down_matrix(n, r):
    m = int(np.ceil(n / r))
    A = np.zeros((m, n))
    for i in range(m):
        s, e = i * r, min((i + 1) * r, n)
        A[i, s:e] = 1.0 / (e - s)
    return A


def gap_masks(B, n, rate, rng):
    b = max(2, int(round(0.05 * n)))
    M = np.ones((B, n), bool)
    for i in range(B):
        while (~M[i]).mean() < rate:
            s = rng.integers(0, max(1, n - b + 1))
            M[i, s:s + b] = False
    return M


class Op:
    """Forward operator. kind in {denoise, deconv, gaps, down}; rows of F are series."""

    def __init__(self, kind, n, width=None, rate=None, factor=None):
        self.kind, self.n = kind, n
        self.rate = rate
        if kind == "denoise":
            self.A = np.eye(n)
        elif kind == "deconv":
            self.width = width
            self.A = conv_matrix(n, width)
        elif kind == "down":
            self.factor = factor
            self.A = down_matrix(n, factor)
        else:
            self.A = None

    @property
    def fixed(self):
        return self.A is not None

    def measure(self, F, sigma, rng, masks=None):
        if self.fixed:
            G = F @ self.A.T
            return G + sigma * rng.standard_normal(G.shape), None
        if masks is None:
            masks = gap_masks(len(F), self.n, self.rate, rng)
        G = masks * (F + sigma * rng.standard_normal(F.shape))
        return G, masks

    def upsample(self, G):
        """Put measurements on the length-n grid without using A (for learned maps)."""
        if self.kind == "down":
            return np.repeat(G, self.factor, axis=1)[:, :self.n]
        return G


# ============================================================ classical solvers
def naive(op, G, M):
    if op.kind == "denoise":
        return G.copy()
    if op.kind == "gaps":
        t = np.arange(op.n)
        return np.vstack([np.interp(t, t[m], g[m]) for g, m in zip(G, M)])
    return G @ np.linalg.pinv(op.A).T


def diffk(n, order):
    return diff1(n) if order == 1 else diff2(n)


def _dtd_banded(n, order):
    L = diffk(n, order)
    Q = L.T @ L
    ab = np.zeros((order + 1, n))
    for k in range(order + 1):
        ab[order - k, k:] = np.diag(Q, k)
    return ab


def tikhonov(op, G, M, par):
    """par = (lambda, derivative order); penalty lambda * ||D_order f||^2."""
    lam, order = par
    n = op.n
    if op.fixed:
        return G @ tikhonov_matrix(op, par).T
    ab0 = lam * _dtd_banded(n, order)
    out = np.empty_like(G)
    for i, (g, m) in enumerate(zip(G, M)):
        ab = ab0.copy()
        ab[order] += m
        out[i] = sla.solveh_banded(ab, m * g)
    return out


def tikhonov_matrix(op, par):
    lam, order = par
    L = diffk(op.n, order)
    return np.linalg.solve(op.A.T @ op.A + lam * L.T @ L, op.A.T)


def _tridiag_factor(dg, e):
    """Batched Thomas factorization for symmetric tridiagonal (diag dg (B,n), constant off-diag e)."""
    B, n = dg.shape
    cp, den = np.empty((B, n)), np.empty((B, n))
    den[:, 0] = dg[:, 0]
    cp[:, 0] = e / den[:, 0]
    for i in range(1, n):
        den[:, i] = dg[:, i] - e * cp[:, i - 1]
        cp[:, i] = e / den[:, i]
    return cp, den


def _tridiag_solve(cp, den, e, r):
    B, n = r.shape
    dp = np.empty_like(r)
    dp[:, 0] = r[:, 0] / den[:, 0]
    for i in range(1, n):
        dp[:, i] = (r[:, i] - e * dp[:, i - 1]) / den[:, i]
    x = np.empty_like(r)
    x[:, -1] = dp[:, -1]
    for i in range(n - 2, -1, -1):
        x[:, i] = dp[:, i] - cp[:, i] * x[:, i + 1]
    return x


def tv_admm(op, G, M, lam, iters, rho=1.0):
    """min 0.5||Af-g||^2 + lam ||Df||_1 via ADMM with splitting z = Df."""
    n = op.n
    D = diff1(n)
    if op.fixed:
        Minv = np.linalg.inv(op.A.T @ op.A + rho * D.T @ D)
        AtG = G @ op.A
        solve = lambda r: r @ Minv.T
    else:
        dtd = np.full(n, 2.0)
        dtd[0] = dtd[-1] = 1.0
        cp, den = _tridiag_factor(M + rho * dtd[None, :], -rho)
        AtG = M * G
        solve = lambda r: _tridiag_solve(cp, den, -rho, r)
    Z = np.zeros((len(G), n - 1))
    U = np.zeros_like(Z)
    for _ in range(iters):
        F = solve(AtG + rho * (Z - U) @ D)
        DF = F @ D.T
        V = DF + U
        Z = np.sign(V) * np.maximum(np.abs(V) - lam / rho, 0)
        U += DF - Z
    return F


def rmse(Fh, F):
    return np.sqrt(np.mean((Fh - F) ** 2, axis=1))


# ============================================================ learned Gaussian prior
class GaussPrior:
    def fit(self, Ftr):
        self.mu = Ftr.mean(0)
        self.S = LedoitWolf().fit(Ftr).covariance_
        return self

    def predict(self, op, G, M, sigma, want_var=False):
        mu, S = self.mu, self.S
        if op.fixed:
            A = op.A
            Sy = A @ S @ A.T + sigma ** 2 * np.eye(A.shape[0])
            K = np.linalg.solve(Sy, A @ S).T                   # n x m
            Fh = mu + (G - mu @ A.T) @ K.T
            var = np.maximum(np.diag(S - K @ A @ S), 1e-12)
            return (Fh, np.tile(var, (len(G), 1))) if want_var else Fh
        Fh, V = np.empty_like(G), np.empty_like(G)
        for i, (g, m) in enumerate(zip(G, M)):
            o = np.flatnonzero(m)
            c = sla.cho_factor(S[np.ix_(o, o)] + sigma ** 2 * np.eye(len(o)))
            Fh[i] = mu + S[:, o] @ sla.cho_solve(c, g[o] - mu[o])
            if want_var:
                W = sla.cho_solve(c, S[o, :])
                V[i] = np.maximum(np.diag(S) - np.einsum("ij,ji->i", S[:, o], W), 1e-12)
        return (Fh, V) if want_var else Fh


# ============================================================ ridge map (fully learned, linear)
def ridge_features(op, G, M):
    X = op.upsample(G)
    return np.hstack([X, M.astype(float)]) if M is not None else X


class RidgeMap:
    def fit(self, op, Ftr, Fval, sigma, rng, reps=5):
        Frep = np.repeat(Ftr, reps, axis=0)[:4000]
        G, M = op.measure(Frep, sigma, rng)
        X = ridge_features(op, G, M)
        Gv, Mv = op.measure(Fval, sigma, rng)
        Xv = ridge_features(op, Gv, Mv)
        self.xm, self.ym = X.mean(0), Frep.mean(0)
        Xc, Yc = X - self.xm, Frep - self.ym
        best = (np.inf, None)
        N, d = Xc.shape
        if d <= N:
            XtX, XtY = Xc.T @ Xc, Xc.T @ Yc
        else:
            XXt = Xc @ Xc.T
        for a in [1e-3, 1e-2, 1e-1, 1, 10, 100, 1000]:
            if d <= N:
                W = np.linalg.solve(XtX + a * N * np.eye(d), XtY)
            else:
                W = Xc.T @ np.linalg.solve(XXt + a * N * np.eye(N), Yc)
            e = np.mean(((Xv - self.xm) @ W + self.ym - Fval) ** 2)
            if e < best[0]:
                best = (e, W)
        self.W = best[1]
        return self

    def predict(self, op, G, M):
        return (ridge_features(op, G, M) - self.xm) @ self.W + self.ym


# ============================================================ neural methods
def conv_stack(c_in, hidden, dilations):
    layers, c = [], c_in
    for d in dilations:
        layers += [nn.Conv1d(c, hidden, 5, padding=2 * d, dilation=d), nn.ReLU()]
        c = hidden
    layers += [nn.Conv1d(c, 1, 5, padding=2)]
    return nn.Sequential(*layers)


class TorchOp:
    def __init__(self, op):
        self.op = op
        self.A = torch.tensor(op.A, dtype=torch.float32) if op.fixed else None

    def fwd(self, F, M):
        return F @ self.A.T if self.A is not None else M * F

    def adj(self, R, M):
        return R @ self.A if self.A is not None else M * R


class DirectCNN(nn.Module):
    """Fully learned: measurements on the grid (+mask) -> series. Does not use A."""

    def __init__(self, gaps, h):
        super().__init__()
        self.gaps = gaps
        self.net = conv_stack(2 if gaps else 1, h, (1, 2, 4, 8, 1))

    def forward(self, gup, x0, M, G, top):
        inp = torch.stack([gup, M], 1) if self.gaps else gup[:, None]
        return gup + self.net(inp)[:, 0]


class PostCNN(nn.Module):
    """Learned post-processing of a classical estimate x0."""

    def __init__(self, gaps, h):
        super().__init__()
        self.gaps = gaps
        self.net = conv_stack(2 if gaps else 1, h, (1, 2, 4, 8, 1))

    def forward(self, gup, x0, M, G, top):
        inp = torch.stack([x0, M], 1) if self.gaps else x0[:, None]
        return x0 + self.net(inp)[:, 0]


class LGD(nn.Module):
    """Unrolled learned gradient descent (Adler & Oktem style): A and A^T in every layer."""

    def __init__(self, gaps, h, K):
        super().__init__()
        self.gaps = gaps
        c = 3 if gaps else 2
        self.blocks = nn.ModuleList([conv_stack(c, h, (1, 2, 4)) for _ in range(K)])

    def forward(self, gup, x0, M, G, top):
        f = x0
        for blk in self.blocks:
            grad = top.adj(top.fwd(f, M) - G, M)
            parts = [f, grad] + ([M] if self.gaps else [])
            f = f + blk(torch.stack(parts, 1))[:, 0]
        return f


def x0_estimate(op, G, M, tik_R):
    """Classical initial estimate: Tikhonov for fixed A, linear interpolation for gaps."""
    return G @ tik_R.T if op.fixed else naive(op, G, M)


def batch_tensors(op, F, sigma, rng, tik_R, masks=None):
    G, M = op.measure(F, sigma, rng, masks)
    x0 = x0_estimate(op, G, M, tik_R)
    Mt = torch.tensor(M, dtype=torch.float32) if M is not None else None
    t = lambda a: torch.tensor(a, dtype=torch.float32)
    return t(op.upsample(G)), t(x0), Mt, t(G)


def train_net(net, op, Ftr, Fval, sigma, rng, tik_R, cfg):
    top = TorchOp(op)
    opt = torch.optim.Adam(net.parameters(), lr=cfg["lr"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, cfg["steps"])
    vrng = np.random.default_rng(12345)
    vb = batch_tensors(op, Fval, sigma, vrng, tik_R)
    Fv = torch.tensor(Fval, dtype=torch.float32)
    best, best_state = np.inf, None
    for step in range(1, cfg["steps"] + 1):
        idx = rng.integers(0, len(Ftr), cfg["batch"])
        F = Ftr[idx]
        gup, x0, M, G = batch_tensors(op, F, sigma, rng, tik_R)
        loss = torch.mean((net(gup, x0, M, G, top) - torch.tensor(F, dtype=torch.float32)) ** 2)
        opt.zero_grad()
        loss.backward()
        opt.step()
        sched.step()
        if step % cfg["eval_every"] == 0 or step == cfg["steps"]:
            with torch.no_grad():
                v = torch.mean((net(*vb, top) - Fv) ** 2).item()
            if v < best:
                best, best_state = v, {k: x.clone() for k, x in net.state_dict().items()}
    net.load_state_dict(best_state)
    return net


def net_predict(net, op, G, M, tik_R, chunk=256):
    top = TorchOp(op)
    x0 = x0_estimate(op, G, M, tik_R)
    out = []
    with torch.no_grad():
        for s in range(0, len(G), chunk):
            sl = slice(s, s + chunk)
            t = lambda a: torch.tensor(a[sl], dtype=torch.float32)
            Mt = t(M) if M is not None else None
            out.append(net(t(op.upsample(G)), t(x0), Mt, t(G), top).numpy())
    return np.vstack(out)


# ============================================================ evaluation helpers
def one_nn_acc(Fh, Ftr, ytr, yte):
    d = (Fh ** 2).sum(1)[:, None] + (Ftr ** 2).sum(1)[None, :] - 2 * Fh @ Ftr.T
    return float(np.mean(ytr[np.argmin(d, 1)] == yte))


def make_op(kind, n, cfg, variant="main"):
    if kind == "deconv":
        w = max(1.0, n / 64)
        return Op("deconv", n, width=w * (1.5 if variant == "mismatch" else 1.0))
    if kind == "gaps":
        return Op("gaps", n, rate=0.5 if variant == "mismatch" else cfg["gap_rate"])
    if kind == "down":
        return Op("down", n, factor=cfg["ds_factor"])
    return Op("denoise", n)


def run_dataset(name, cfg=CFG):
    seed = zlib.crc32(name.encode()) % (2 ** 31)
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    Xtr, Xte, meta, ytr, yte = ucr_io.load(name, with_labels=True)
    n_orig = Xtr.shape[1]
    Ftr_all, Fte = prep(Xtr, cfg["max_len"]), prep(Xte, cfg["max_len"])
    if len(Ftr_all) > cfg["max_train"]:
        i = rng.choice(len(Ftr_all), cfg["max_train"], replace=False)
        Ftr_all, ytr = Ftr_all[i], ytr[i]
    if len(Fte) > cfg["max_test"]:
        i = rng.choice(len(Fte), cfg["max_test"], replace=False)
        Fte, yte = Fte[i], yte[i]
    n = Ftr_all.shape[1]
    perm = rng.permutation(len(Ftr_all))
    nval = max(2, int(round(0.1 * len(Ftr_all))))
    Fval, Ftr = Ftr_all[perm[:nval]], Ftr_all[perm[nval:]]
    sigma = cfg["sigma"]
    res = dict(dataset=name, n_orig=n_orig, n=n, n_train=len(Ftr_all), n_test=len(Fte),
               n_classes=int(len(np.unique(ytr))), acc_clean=one_nn_acc(Fte, Ftr_all, ytr, yte), tasks={})
    gp = GaussPrior().fit(Ftr_all)
    examples = {}

    for kind in TASKS:
        op = make_op(kind, n, cfg)
        r = {m: {} for m in METHODS}
        # ---- tuning pairs (from training series only)
        Ft = Ftr_all[:cfg["tune_n"]]
        Gt, Mt = op.measure(Ft, sigma, rng)
        t0 = time.time()
        grid = [(l, o) for o in (1, 2) for l in cfg["tik_grid"]]
        e = [rmse(tikhonov(op, Gt, Mt, p), Ft).mean() for p in grid]
        lam_tik = grid[int(np.argmin(e))]
        r["Tikhonov"]["train_s"] = time.time() - t0
        t0 = time.time()
        e = [rmse(tv_admm(op, Gt, Mt, l, cfg["admm_tune_iters"], cfg["rho"]), Ft).mean() for l in cfg["tv_grid"]]
        lam_tv = cfg["tv_grid"][int(np.argmin(e))]
        r["TV"]["train_s"] = time.time() - t0
        r["Tikhonov"]["lambda"], r["TV"]["lambda"] = lam_tik, lam_tv
        tik_R = tikhonov_matrix(op, lam_tik) if op.fixed else None

        # ---- learned models
        models = {}
        t0 = time.time()
        models["Ridge"] = RidgeMap().fit(op, Ftr, Fval, sigma, rng)
        r["Ridge"]["train_s"] = time.time() - t0
        gaps = kind == "gaps"
        for mname, net in [("LGD", LGD(gaps, cfg["hidden"], cfg["lgd_K"])),
                           ("PostCNN", PostCNN(gaps, cfg["hidden"])),
                           ("DirectCNN", DirectCNN(gaps, cfg["hidden"]))]:
            t0 = time.time()
            models[mname] = train_net(net, op, Ftr, Fval, sigma, rng, tik_R, cfg)
            r[mname]["train_s"] = time.time() - t0
            r[mname]["params"] = int(sum(p.numel() for p in net.parameters()))

        def predict_all(op_e, G, M, tikR_e, iters, want_var=False):
            out, var, tm = {}, None, {}
            steps = [
                ("Classical", lambda: naive(op_e, G, M)),
                ("Tikhonov", lambda: tikhonov(op_e, G, M, lam_tik)),
                ("TV", lambda: tv_admm(op_e, G, M, lam_tv, iters, cfg["rho"])),
                ("Ridge", lambda: models["Ridge"].predict(op_e, G, M)),
                ("LGD", lambda: net_predict(models["LGD"], op_e, G, M, tikR_e)),
                ("PostCNN", lambda: net_predict(models["PostCNN"], op_e, G, M, tikR_e)),
                ("DirectCNN", lambda: net_predict(models["DirectCNN"], op_e, G, M, tikR_e)),
            ]
            for m, fn in steps:
                t0 = time.time()
                out[m] = fn()
                tm[m] = time.time() - t0
            t0 = time.time()
            if want_var:
                out["GaussPrior"], var = gp.predict(op_e, G, M, sigma, want_var=True)
            else:
                out["GaussPrior"] = gp.predict(op_e, G, M, sigma)
            tm["GaussPrior"] = time.time() - t0
            return out, var, tm

        # ---- main evaluation
        G, M = op.measure(Fte, sigma, rng)
        out, var, tm = predict_all(op, G, M, tik_R, cfg["admm_iters"], want_var=True)
        for m in METHODS:
            e = rmse(out[m], Fte)
            r[m]["nrmse"] = float(e.mean())
            r[m]["nrmse_median"] = float(np.median(e))
            r[m]["acc"] = one_nn_acc(out[m], Ftr_all, ytr, yte)
            r[m]["infer_s_per_series"] = tm[m] / len(Fte)
        sd = np.sqrt(var)
        z = np.abs(out["GaussPrior"] - Fte) / sd
        r["GaussPrior"]["coverage90"] = float(np.mean(z <= 1.6449))
        r["GaussPrior"]["coverage50"] = float(np.mean(z <= 0.6745))
        r["GaussPrior"]["width90"] = float(np.mean(2 * 1.6449 * sd))
        if name in ("ECG5000", "StarLightCurves", "ItalyPowerDemand", "FordA"):
            examples[kind] = dict(f=Fte[:3], g=G[:3], mask=None if M is None else M[:3],
                                  **{m: out[m][:3] for m in METHODS}, gp_sd=sd[:3])

        # ---- robustness: noise misspecification and operator mismatch (first robust_test series)
        Fr = Fte[:cfg["robust_test"]]
        for s_test in (0.05, 0.2):
            G, M = op.measure(Fr, s_test, rng)
            out, _, _ = predict_all(op, G, M, tik_R, cfg["admm_iters"])
            for m in METHODS:
                r[m][f"nrmse_sigma{s_test}"] = float(rmse(out[m], Fr).mean())
        if kind in ("deconv", "gaps"):
            op_m = make_op(kind, n, cfg, "mismatch")
            tikR_m = tikhonov_matrix(op_m, lam_tik) if op_m.fixed else None
            G, M = op_m.measure(Fr, sigma, rng)
            out, _, _ = predict_all(op_m, G, M, tikR_m, cfg["admm_iters"])
            for m in METHODS:
                r[m]["nrmse_mismatch"] = float(rmse(out[m], Fr).mean())
        res["tasks"][kind] = r

    if examples:
        np.savez_compressed(os.path.join(OUT, f"examples_{name}.npz"),
                            **{f"{k}__{kk}": vv for k, v in examples.items() for kk, vv in v.items() if vv is not None})
    return res


def usable():
    import csv
    with open(paths.META) as fh:
        rows = list(csv.DictReader(fh))
    ok = [r for r in rows if r["equal"] == "True" and r["has_nan"] == "False"]
    # order by cost (longest first so load balances), deterministic
    ok.sort(key=lambda r: -min(int(r["length"]), 256) * min(int(r["n_test"]), 1000))
    return [r["name"] for r in ok]


if __name__ == "__main__":
    torch.set_num_threads(1)
    wid, nw = int(sys.argv[1]), int(sys.argv[2])
    only = sys.argv[3].split(",") if len(sys.argv) > 3 else None
    os.makedirs(OUT, exist_ok=True)
    names = only if only else usable()[wid::nw]
    for name in names:
        path = os.path.join(OUT, f"{name}.json")
        if os.path.exists(path):
            continue
        t0 = time.time()
        try:
            res = run_dataset(name)
            res["wall_s"] = time.time() - t0
            with open(path, "w") as fh:
                json.dump(res, fh)
            print(f"[{wid}] {name} done in {time.time() - t0:.0f}s", flush=True)
        except Exception as exc:  # keep going; log failures
            print(f"[{wid}] {name} FAILED: {exc!r}", flush=True)
