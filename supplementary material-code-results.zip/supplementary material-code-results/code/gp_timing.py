"""Timing of the learned Gaussian prior fit (Table 8, 'separate timing run').

    python gp_timing.py            # uses UCR data if available (see paths.py), otherwise synthetic series

Procedure: series of length n = 256 (the UCR dataset with the most training series among those with at least 256 samples, resampled to 256 and
z-normalised exactly as in the benchmark; or, without the data, smooth synthetic series), a single thread
(OMP_NUM_THREADS = 1 is set below before NumPy is imported), and N in {50, 100, 200, 500, 1000, 2000}
training series. For each N the fit (sample mean + sklearn LedoitWolf covariance) is timed with
time.perf_counter over 7 repetitions after one warm-up call; the median is reported. The per-mask
posterior solve at inference time is timed separately for gap filling (median over 300 test series).
"""
import os
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(v, "1")
import time
import platform
import numpy as np
import pandas as pd

import paths
from bench import CFG, prep, make_op, GaussPrior

NS = [50, 100, 200, 500, 1000, 2000]


def load_series(n_needed):
    try:
        import ucr_io
        meta = pd.read_csv(paths.META)
        ok = meta[(meta.equal.astype(str) == "True") & (meta.has_nan.astype(str) == "False")]
        ok = ok[(pd.to_numeric(ok.length) >= 256) & (pd.to_numeric(ok.n_train) >= n_needed)]
        name = ok.sort_values("n_train", ascending=False).name.iloc[0]
        Xtr, _, _ = ucr_io.load(name)
        F = prep(Xtr, CFG["max_len"])
        if F.shape[1] == 256 and len(F) >= n_needed:
            return F[:n_needed], f"UCR {name}"
    except Exception:
        pass
    rng = np.random.default_rng(0)
    F = np.cumsum(rng.standard_normal((n_needed, 256)), 1)
    return (F - F.mean(1, keepdims=True)) / F.std(1, keepdims=True), "synthetic random walks"


def timeit(fn, reps=7):
    fn()
    t = []
    for _ in range(reps):
        t0 = time.perf_counter(); fn(); t.append(time.perf_counter() - t0)
    return float(np.median(t))


def main():
    F, src = load_series(max(NS) + 300)
    rows = [dict(N=N, fit_s=timeit(lambda: GaussPrior().fit(F[:N]))) for N in NS]
    gp = GaussPrior().fit(F[:1000])
    op = make_op("gaps", 256, CFG)
    G, M = op.measure(F[-300:], CFG["sigma"], np.random.default_rng(1))
    inf = timeit(lambda: gp.predict(op, G, M, CFG["sigma"]), reps=3) / len(G)
    R = pd.DataFrame(rows)
    print(f"data: {src}; n = 256; threads = 1; {platform.processor() or platform.machine()}")
    print(R.to_string(index=False, float_format="%.4f"))
    print(f"gap-filling inference (per-mask Cholesky solve): {1000 * inf:.3f} ms per series")
    R.to_csv(os.path.join(paths.OUT, "table_gp_timing.csv"), index=False)


if __name__ == "__main__":
    main()
