"""Shared constants (kept identical to bench.py) so analysis and figure code do not need PyTorch."""
TASKS = ["denoise", "deconv", "gaps", "down"]
METHODS = ["Classical", "Tikhonov", "TV", "GaussPrior", "LGD", "PostCNN", "DirectCNN", "Ridge"]
