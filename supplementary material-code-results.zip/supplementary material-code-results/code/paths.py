"""Single source of truth for all paths. Override with environment variables if needed."""
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))          # package root
DATA = os.environ.get("UCR_DIR", os.path.join(ROOT, "data", "Univariate_ts"))
RESULTS = os.environ.get("RESULTS_DIR", os.path.join(ROOT, "results"))
MAIN = os.path.join(RESULTS, "per_dataset")
SWEEP = os.path.join(RESULTS, "followup_sweep")
BUDGET = os.path.join(RESULTS, "followup_budget")
REV = os.path.join(RESULTS, "revision")
OUT = os.path.join(RESULTS, "tables")
META = os.path.join(ROOT, "code", "meta.csv")
for _d in (MAIN, SWEEP, BUDGET, REV, OUT):
    os.makedirs(_d, exist_ok=True)
