"""Check every number in the manuscript's Tables 3-6 against the stored CSV outputs.

    python audit_tables.py [path/to/Manuscript.docx]

Requires python-docx. Reads results/tables/*.csv (from analysis.py and analysis_new.py) and compares each table
cell, as printed, with the value recomputed from the CSV and rounded the same way. Prints mismatches and a summary.
"""
import os
import re
import sys

import pandas as pd
import docx

import paths

T = paths.OUT
DOC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(paths.ROOT, "paper", "Manuscript.docx")
METH = {"Classical": "Classical", "Tikhonov": "Tikhonov", "TV": "TV", "Learned Gaussian prior": "GaussPrior", "Unrolled LGD": "LGD",
        "CNN post-processing": "PostCNN", "Fully learned CNN": "DirectCNN", "Ridge map": "Ridge", "Plug-and-play (PnP)": "PnP",
        "SAITS": "SAITS", "BRITS": "BRITS"}


def tables_after_caption(d):
    """Map 'Table k' -> list of rows (list of cell texts) for the table following each caption."""
    out, pending = {}, None
    for el in d.element.body.iterchildren():
        tag = el.tag.split("}")[1]
        if tag == "p":
            txt = "".join(t.text or "" for t in el.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t"))
            m = re.match(r"Table (\d+)\.", txt)
            if m:
                pending = int(m.group(1))
        elif tag == "tbl" and pending is not None:
            t = docx.table.Table(el, d)
            rows = []
            for r in t.rows:
                cells, seen = [], set()
                for c in r.cells:
                    if id(c._tc) in seen:
                        continue
                    seen.add(id(c._tc))
                    cells.append(c.text.strip())
                rows.append(cells)
            out[pending] = rows
            pending = None
    return out


def num(s):
    s = s.replace("†", "").replace("*", "").strip()
    return float(s)


problems, checked = [], 0


def check(table, where, printed, expected, digits):
    global checked
    checked += 1
    if f"{expected:.{digits}f}" != f"{num(printed):.{digits}f}":
        problems.append(f"Table {table} {where}: printed {printed}, CSV gives {expected:.{digits}f}")


def main():
    d = docx.Document(DOC)
    tabs = tables_after_caption(d)

    # Table 3: rank and ratio per task
    main_csv = pd.read_csv(os.path.join(T, "table_main.csv")).set_index(["task", "method"])
    tasks = ["denoise", "deconv", "gaps", "down"]
    for row in tabs[3][2:]:
        m = METH[row[0]]
        for i, t in enumerate(tasks):
            r, q = row[1 + 2 * i], row[2 + 2 * i]
            check(3, f"{row[0]} {t} rank", r, main_csv.loc[(t, m), "avg_rank"], 2)
            if not q.startswith(">"):
                check(3, f"{row[0]} {t} ratio", q, main_csv.loc[(t, m), "gmean_ratio_vs_tik"], 3)
            dagger = "†" in r
            sig = main_csv.loc[(t, m), "p_holm_vs_best"]
            if dagger != (sig >= 0.05 and not main_csv.loc[(t, m), "best"]):
                problems.append(f"Table 3 {row[0]} {t}: dagger {dagger} but p_holm_vs_best = {sig:.3g}")

    # Table 4: ablation
    ab = pd.read_csv(os.path.join(T, "table_ablation113.csv"))
    ab = ab[ab.kind == "ablation"]
    labels = {"Loop (init uses A)": "loop | init uses A", "Loop (init without A)": "loop | init without A",
              "Init (loop uses A)": "init | loop uses A", "Init (loop without A)": "init | loop without A", "Both vs neither": "both vs neither"}
    cols = [("deconv", "nrmse"), ("deconv", "nrmse_mismatch"), ("gaps", "nrmse"), ("gaps", "nrmse_mismatch"), ("gaps", "nrmse_missing"), ("down", "nrmse")]
    for row in tabs[4][1:]:
        lab = labels[row[0].replace("𝒜", "A").replace(" )", " A)")]          # the symbol is an equation object, absent from cell text
        for (t, c), cell in zip(cols, row[1:]):
            r = ab[(ab.task == t) & (ab.cond == c) & (ab.comparison == lab)].iloc[0]
            g, n = re.match(r"([\d.]+)\**\s*\((\d+)\)", cell).groups()
            check(4, f"{row[0]} {t}/{c} ratio", g, r.gmean_ratio, 3)
            check(4, f"{row[0]} {t}/{c} count", n, r.with_better, 0)
            stars = cell.count("*")
            exp = 2 if r.p_holm < 0.01 else 1 if r.p_holm < 0.05 else 0
            if stars != exp:
                problems.append(f"Table 4 {row[0]} {t}/{c}: {stars} stars, Holm p = {r.p_holm:.3g}")

    # Table 5: baselines
    bl = pd.read_csv(os.path.join(T, "table_baselines.csv"))
    cols = [("gaps", "nominal", "missing"), ("gaps", "shift", "missing"), ("deconv", "nominal", "full"), ("deconv", "shift", "full")]
    for row in tabs[5][1:]:
        m = METH[row[0]]
        for (t, c, pts), cell in zip(cols, row[1:]):
            if cell == "–":
                continue
            g, r = [x.strip() for x in cell.split("/")]
            e = bl[(bl.task == t) & (bl.cond == c) & (bl.points == pts) & (bl.method == m)].iloc[0]
            check(5, f"{row[0]} {t}/{c} ratio", g, e.gmean_vs_Tik, 3)
            check(5, f"{row[0]} {t}/{c} rank", r, e["rank"], 2)

    # Table 6: normalisation (calibrated estimate and matched, relative to oracle)
    nz = pd.read_csv(os.path.join(T, "table_normalisation.csv"))
    cols = [("denoise", "obs_cal"), ("deconv", "obs_cal"), ("deconv", "matched"), ("gaps", "obs_cal"), ("gaps", "matched"), ("down", "obs_cal"), ("down", "matched")]
    for row in tabs[6][2:]:
        m = METH[row[0]]
        for (t, c), cell in zip(cols, row[1:]):
            e = nz[(nz.task == t) & (nz.cond == c) & (nz.method == m)].iloc[0]
            check(6, f"{row[0]} {t}/{c}", cell, e.gmean_vs_oracle, 3)

    print(f"{checked} numbers checked in Tables 3-6; {len(problems)} problem(s)")
    for p in problems:
        print("  ", p)
    return len(problems)


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
