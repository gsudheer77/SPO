"""Compare an independent re-run of the experiments with the results used in the paper.

Usage (from code/):
    python compare_runs.py ../results_reproduction/laptop_win11

The argument is a results folder with the same layout as ../results (per_dataset/, followup_sweep/,
followup_budget/, revision/A|B|C/). Its tables/ subfolder is regenerated first if missing, by running
the analysis scripts with RESULTS_DIR pointing there (budget_ref.py needs the UCR data and is skipped;
the re-run's own table_budget_full.csv is used if present).

Writes ../results/tables/reproduction_values.csv  (relative differences of every stored metric, by group)
and   ../results/tables/reproduction_tables.csv  (paper-table entries side by side)
and prints a summary, including every significance decision (p < 0.05) that differs between the runs.
"""
import os
import re
import sys
import glob
import json
import subprocess
import numpy as np
import pandas as pd

import paths

HERE = os.path.dirname(os.path.abspath(__file__))
# The second-machine re-run reproduces the experiments as first run: the 40-dataset ablation (revision/B_v1_40)
# and the first seeded sweep (revision/C_v1). The paper now uses later runs (revision/B on 113 datasets,
# revision/C re-run), so the reference is assembled in a temporary folder with those original runs in place.
A_DIR = None
B_DIR = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else sys.exit(__doc__)
SUBS = ["per_dataset", "followup_sweep", "followup_budget", "revision/A", "revision/B", "revision/C"]
LEARNED = {"LGD", "PostCNN", "DirectCNN", "LGD_noA", "LGD_noAinit", "LGD_noAloop"}
TIMING = re.compile(r"(^train_s$|infer|wall)")


def flat(o, p=()):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from flat(v, p + (str(k),))
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from flat(v, p + (str(i),))
    else:
        yield p, o


def regenerate_tables(res):
    if os.path.exists(os.path.join(res, "tables", "table_main.csv")):
        return
    env = dict(os.environ, RESULTS_DIR=res)
    for s in ["analysis.py", "figs2.py", "stats2.py", "analysis_rev.py"]:
        subprocess.run([sys.executable, s], cwd=HERE, env=env, check=True, stdout=subprocess.DEVNULL)


def compare_values():
    rows = []
    for sub in SUBS:
        for fa in sorted(glob.glob(os.path.join(A_DIR, sub, "*.json"))):
            fb = os.path.join(B_DIR, sub, os.path.basename(fa))
            if not os.path.exists(fb):
                rows.append(dict(group=f"{sub}|MISSING", rel=np.nan)); continue
            a = dict(flat(json.load(open(fa)))); b = dict(flat(json.load(open(fb))))
            for k in a.keys() & b.keys():
                x, y = a[k], b[k]
                if isinstance(x, bool) or not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
                    continue
                if any(TIMING.search(s) for s in k):
                    kind = "timing"
                elif any(s in LEARNED for s in k) or any(s.startswith("DirectCNN") or s.startswith("LGD") for s in k):
                    kind = "learned"
                elif "Classical" in k and "deconv" in k:
                    kind = "pseudo-inverse (ill-conditioned)"
                else:
                    kind = "deterministic"
                rel = 0.0 if x == y else abs(x - y) / max(abs(x), 1e-12)
                rows.append(dict(group=f"{sub}|{kind}", rel=rel))
    df = pd.DataFrame(rows)
    s = df.groupby("group").rel.agg(n="size", median="median", p95=lambda v: v.quantile(.95), max="max")
    return s


def reference_dir():
    import shutil, tempfile
    ref = os.path.join(tempfile.mkdtemp(prefix="ref_results_"), "results")
    R = paths.RESULTS
    for sub in ["per_dataset", "followup_sweep", "followup_budget", "revision/A"]:
        shutil.copytree(os.path.join(R, sub), os.path.join(ref, sub))
    for sub, src in [("revision/B", "revision/B_v1_40"), ("revision/C", "revision/C_v1")]:
        shutil.copytree(os.path.join(R, src if os.path.isdir(os.path.join(R, src)) else sub), os.path.join(ref, sub))
    os.makedirs(os.path.join(ref, "tables"))
    shutil.copy(os.path.join(R, "tables", "table_budget_full.csv"), os.path.join(ref, "tables"))   # needs data to rebuild
    regenerate_tables(ref)
    return ref


def main():
    global A_DIR
    A_DIR = reference_dir()
    regenerate_tables(B_DIR)
    TA, TB = os.path.join(A_DIR, "tables"), os.path.join(B_DIR, "tables")
    pd.set_option("display.width", 200)

    s = compare_values()
    s.to_csv(os.path.join(paths.OUT, "reproduction_values.csv"))
    print("Relative difference of stored values (paper run vs re-run):\n", s.to_string(float_format="%.2e"), "\n")

    # headline statistic for the networks: nominal mean NRMSE in the main benchmark
    d = []
    for fa in sorted(glob.glob(os.path.join(A_DIR, "per_dataset", "*.json"))):
        fb = os.path.join(B_DIR, "per_dataset", os.path.basename(fa))
        ra, rb = json.load(open(fa)), json.load(open(fb))
        for t in ra["tasks"]:
            for m in ("LGD", "PostCNN", "DirectCNN"):
                x, y = ra["tasks"][t][m]["nrmse"], rb["tasks"][t][m]["nrmse"]
                d.append((100 * abs(y - x) / x, ra["dataset"], t, m))
    v = np.array([z[0] for z in d])
    print("Networks, nominal mean test NRMSE in the main benchmark (%d values): |relative difference| median %.3f%%, "
          "95th percentile %.3f%%, max %.2f%% (%s)\n" % (len(v), np.median(v), np.quantile(v, .95), v.max(), " / ".join(max(d)[1:])))

    # paper tables side by side
    out = []
    key = {"table_main.csv": ["task", "method"], "table_pairs.csv": ["task", "a", "b"],
           "table_ablation_pairs.csv": ["task", "cond", "comparison"], "table_ablation_arch.csv": ["task", "cond", "a", "b"],
           "table_budget.csv": ["task", "method"], "table_mismatch_paired.csv": ["task", "method"]}
    flips = []
    for f, k in key.items():
        A = pd.read_csv(os.path.join(TA, f)); B = pd.read_csv(os.path.join(TB, f))
        M = A.merge(B, on=k, suffixes=("_paper", "_rerun"))
        M.insert(0, "table", f); out.append(M)
        for pcol in [c for c in A.columns if c in ("p", "p_holm", "p_wilcoxon", "p_holm_vs_best")]:
            pa, pb = M[pcol + "_paper"], M[pcol + "_rerun"]
            d = M[(pa < 0.05) != (pb < 0.05)]
            for _, r in d.iterrows():
                flips.append(dict(table=f, row=" / ".join(str(r[c]) for c in k), test=pcol,
                                  p_paper=r[pcol + "_paper"], p_rerun=r[pcol + "_rerun"]))
    pd.concat(out).to_csv(os.path.join(paths.OUT, "reproduction_tables.csv"), index=False)

    a = pd.read_csv(os.path.join(TA, "table_main.csv")); b = pd.read_csv(os.path.join(TB, "table_main.csv"))
    m = a.merge(b, on=["task", "method"], suffixes=("_a", "_b"))
    m = m[m.method != "Classical"]
    print("Table 3: same best method per task:", bool((m.best_a == m.best_b).all()))
    print("  max |change| avg rank %.3f, error ratio %.4f, wins %d, beats Tikhonov %d" % (
        (m.avg_rank_a - m.avg_rank_b).abs().max(), (m.gmean_ratio_vs_tik_a - m.gmean_ratio_vs_tik_b).abs().max(),
        (m.wins_a - m.wins_b).abs().max(), (m.better_than_tik_a - m.better_than_tik_b).abs().max()))
    print("\nSignificance decisions (p < 0.05) that differ between the runs:")
    print(pd.DataFrame(flips).to_string(index=False, float_format="%.4f") if flips else "  none")


if __name__ == "__main__":
    main()
