"""Follow-up studies.

  python extra.py sweep  <worker> <n_workers>   controlled training-size sweep (large datasets)
  python extra.py budget <worker> <n_workers>   training-budget check (500 vs 2000 steps)
"""
import os
import sys
import json
import zlib
import numpy as np
import torch

import bench
import ucr_io
from bench import (CFG, prep, make_op, tikhonov, tikhonov_matrix, rmse, GaussPrior, RidgeMap,
                   LGD, PostCNN, DirectCNN, train_net, net_predict)

HERE = os.path.dirname(os.path.abspath(__file__))
SWEEP_SETS = ["ElectricDevices", "Crop", "FordA", "StarLightCurves", "Wafer", "TwoPatterns"]
SWEEP_N = [16, 32, 64, 128, 256, 512, 1024]
BUDGET_SETS = ["ECG5000", "ItalyPowerDemand", "SwedishLeaf", "Symbols", "Strawberry", "Trace",
               "MedicalImages", "SonyAIBORobotSurface2"]


def data(name, max_train=None):
    rng = np.random.default_rng(zlib.crc32(name.encode()) % (2 ** 31))
    Xtr, Xte, _ = ucr_io.load(name)
    Ftr, Fte = prep(Xtr, CFG["max_len"]), prep(Xte, CFG["max_len"])
    Ftr = Ftr[rng.permutation(len(Ftr))]
    Fte = Fte[rng.choice(len(Fte), min(300, len(Fte)), replace=False)]
    return Ftr, Fte, rng


def fit_eval(kind, Ftr_all, Fte, rng, steps, methods):
    cfg = dict(CFG)
    cfg["steps"] = steps
    n = Ftr_all.shape[1]
    op = make_op(kind, n, cfg)
    sigma = cfg["sigma"]
    nval = max(2, int(round(0.1 * len(Ftr_all))))
    Fval, Ftr = Ftr_all[:nval], Ftr_all[nval:]
    Ft = Ftr_all[:cfg["tune_n"]]
    Gt, Mt = op.measure(Ft, sigma, rng)
    grid = [(l, o) for o in (1, 2) for l in cfg["tik_grid"]]
    lam = grid[int(np.argmin([rmse(tikhonov(op, Gt, Mt, p), Ft).mean() for p in grid]))]
    tikR = tikhonov_matrix(op, lam) if op.fixed else None
    G, M = op.measure(Fte, sigma, np.random.default_rng(7))
    out = {}
    if "Tikhonov" in methods:
        out["Tikhonov"] = rmse(tikhonov(op, G, M, lam), Fte).mean()
    if "GaussPrior" in methods:
        out["GaussPrior"] = rmse(GaussPrior().fit(Ftr_all).predict(op, G, M, sigma), Fte).mean()
    if "Ridge" in methods:
        out["Ridge"] = rmse(RidgeMap().fit(op, Ftr, Fval, sigma, rng).predict(op, G, M), Fte).mean()
    gaps = kind == "gaps"
    nets = {"LGD": lambda: LGD(gaps, cfg["hidden"], cfg["lgd_K"]), "PostCNN": lambda: PostCNN(gaps, cfg["hidden"]),
            "DirectCNN": lambda: DirectCNN(gaps, cfg["hidden"])}
    for m, mk in nets.items():
        if m in methods:
            net = train_net(mk(), op, Ftr, Fval, sigma, rng, tikR, cfg)
            out[m] = rmse(net_predict(net, op, G, M, tikR), Fte).mean()
    return {k: float(v) for k, v in out.items()}


def main():
    torch.set_num_threads(1)
    mode, wid, nw = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    import paths
    od = {"sweep": paths.SWEEP, "budget": paths.BUDGET}[mode]
    os.makedirs(od, exist_ok=True)
    if mode == "sweep":
        jobs = [(d, N, k) for d in SWEEP_SETS for N in SWEEP_N for k in ("gaps", "deconv")]
    else:
        jobs = [(d, s, k) for d in BUDGET_SETS for s in (500, 2000) for k in ("gaps", "down")]
    for i, (d, x, kind) in enumerate(jobs):
        if i % nw != wid:
            continue
        path = os.path.join(od, f"{d}_{kind}_{x}.json")
        if os.path.exists(path):
            continue
        torch.manual_seed(0)
        Ftr, Fte, rng = data(d)
        if mode == "sweep":
            res = fit_eval(kind, Ftr[:x], Fte, rng, CFG["steps"],
                           ["Tikhonov", "GaussPrior", "Ridge", "LGD", "PostCNN", "DirectCNN"])
        else:
            res = fit_eval(kind, Ftr[:CFG["max_train"]], Fte, rng, x, ["LGD", "PostCNN", "DirectCNN"])
        json.dump(dict(dataset=d, task=kind, x=x, **res), open(path, "w"))
        print(mode, d, kind, x, {k: round(v, 3) for k, v in res.items()}, flush=True)


if __name__ == "__main__":
    main()
