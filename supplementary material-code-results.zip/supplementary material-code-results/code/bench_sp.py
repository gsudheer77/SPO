"""Additional experiments for the Signal Processing submission (responding to pre-submission review).

  python bench_sp.py <part> <worker_id> <n_workers> [dataset1,dataset2,...]

Parts (results -> ../results/sp/<part>/<dataset>.json):
  N  realistic normalisation: test series normalised with statistics estimated from the OBSERVATIONS
     (mean/std of observed values, std rescaled by a factor calibrated on training series only)
     instead of the clean signal; all four tasks; models are those of the oracle protocol, because
     clean training series may legitimately be normalised with their own statistics.
  R  resampling and length (datasets with original length > 256): linear interpolation to 256 (as in the
     paper), anti-aliased polyphase resampling to 256 (scipy.signal.resample_poly, Kaiser FIR), and the
     original length (capped at 1,024 samples by keeping the first 1,024 if longer is NOT done; the full
     original length is used).  All four tasks, nominal operators.
  K  deconvolution robustness: (i) known kernel changes with width factor 0.5, 0.75, 1.25, 1.5, 2.0;
     (ii) operator misspecification: true width (1+d) w, methods use the nominal w, d in -20..+20 %.
     Includes the matched-ablation variants of the unrolled network and the plug-and-play baseline.
  P  stronger baselines: plug-and-play HQS with a learned noise-conditional CNN denoiser (all four tasks,
     nominal and shifted operators) and, for gap filling, SAITS and BRITS (PyPOTS implementations).
  T  training budget and seeds: gap filling and downsampling, LGD / CNN post-processing / fully learned
     CNN at 500 and 2,000 steps, three seeds each, against the learned Gaussian prior.

The default dataset list is SP_SETS (20 datasets, stratified by domain, length and training-set size). An optional
4th argument gives a comma-separated list or "all" (the 113 usable datasets). The submitted results used: K, N, T and R
on "all" (R skips series of length <= 256), and P on the first 20 datasets in alphabetical order (see README section 7).
"""
import os
import sys
import json
import time
import zlib
from fractions import Fraction

import numpy as np
import torch
import torch.nn as nn
from scipy.signal import resample_poly

import ucr_io
import paths
import bench
from bench import (CFG, make_op, naive, tikhonov, tikhonov_matrix, tv_admm, rmse, GaussPrior, RidgeMap,
                   LGD, PostCNN, DirectCNN, conv_stack, Op, train_net, net_predict, x0_estimate)
from bench_rev import LGDAblate, make_init, train_generic, predict_generic, missing_rmse

SP_SETS = ["ACSF1", "ArrowHead", "CinCECGTorso", "Crop", "ECG5000", "ElectricDevices", "EOGHorizontalSignal",
           "FordA", "GunPoint", "ItalyPowerDemand", "Lightning2", "MedicalImages", "OSULeaf",
           "SonyAIBORobotSurface2", "StarLightCurves", "Strawberry", "SwedishLeaf", "Symbols", "Trace", "Wafer"]
RES = os.path.join(paths.RESULTS, "sp")
SIG = CFG["sigma"]


# ------------------------------------------------------------------ data
def znorm(X):
    mu, sd = X.mean(1, keepdims=True), X.std(1, keepdims=True)
    sd[sd < 1e-8] = 1.0
    return (X - mu) / sd


def resample(X, n_new, how):
    X = np.asarray(X, float)
    n = X.shape[1]
    if how == "orig" or n <= n_new:
        return X
    if how == "linear":
        t_old, t_new = np.linspace(0, 1, n), np.linspace(0, 1, n_new)
        return np.vstack([np.interp(t_new, t_old, x) for x in X])
    fr = Fraction(n_new, n).limit_denominator(1000)
    Y = resample_poly(X, fr.numerator, fr.denominator, axis=1, padtype="line")
    if Y.shape[1] != n_new:                                     # rational approximation: fix the last samples
        Y = np.vstack([np.interp(np.linspace(0, 1, n_new), np.linspace(0, 1, Y.shape[1]), y) for y in Y])
    return Y


def load(name, rng, how="linear", max_len=256):
    Xtr, Xte, _, ytr, yte = ucr_io.load(name, with_labels=True)
    Ftr, Fte = znorm(resample(Xtr, max_len, how)), znorm(resample(Xte, max_len, how))
    if len(Ftr) > CFG["max_train"]:
        Ftr = Ftr[rng.choice(len(Ftr), CFG["max_train"], replace=False)]
    if len(Fte) > 300:
        Fte = Fte[rng.choice(len(Fte), 300, replace=False)]
    return Ftr, Fte, Xtr.shape[1]


def split_val(Ftr_all, seed):
    perm = np.random.default_rng(seed + 1).permutation(len(Ftr_all))
    nval = max(2, int(round(0.1 * len(Ftr_all))))
    return Ftr_all[perm[nval:]], Ftr_all[perm[:nval]], perm


def deconv_op(n, factor=1.0):
    return Op("deconv", n, width=max(1.0, n / 64) * factor)


# ------------------------------------------------------------------ plug-and-play baseline
class Denoiser(nn.Module):
    """Noise-level-conditional residual CNN (DnCNN/FFDNet style): input (x, sigma map)."""

    def __init__(self, h):
        super().__init__()
        self.net = conv_stack(2, h, (1, 2, 4, 8, 1))

    def forward(self, x, s):
        return x - self.net(torch.stack([x, s.expand_as(x)], 1))[:, 0]


def train_denoiser(Ftr, rng, steps, h=32):
    net = Denoiser(h)
    opt = torch.optim.Adam(net.parameters(), lr=CFG["lr"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, steps)
    for _ in range(steps):
        F = torch.tensor(Ftr[rng.integers(0, len(Ftr), CFG["batch"])], dtype=torch.float32)
        s = torch.tensor(np.exp(rng.uniform(np.log(0.01), np.log(1.0), (len(F), 1))), dtype=torch.float32)
        x = F + s * torch.randn_like(F)
        loss = torch.mean((net(x, s) - F) ** 2)
        opt.zero_grad()
        loss.backward()
        opt.step()
        sched.step()
    return net


def pnp_hqs(den, op, G, M, sigma, lam, s1, x0, K=8):
    """Half-quadratic splitting with a learned denoiser (DPIR schedule, Zhang et al. 2021)."""
    sig_k = np.geomspace(s1, sigma, K)
    z = x0.copy()
    if op.fixed:
        A = op.A
        AtA, AtG = A.T @ A, G @ A
    for sk in sig_k:
        mu = lam * sigma ** 2 / sk ** 2
        if op.fixed:
            f = np.linalg.solve(AtA + mu * np.eye(op.n), (AtG + mu * z).T).T
        else:
            f = (M * G + mu * z) / (M + mu)
        with torch.no_grad():
            z = den(torch.tensor(f, dtype=torch.float32),
                    torch.full((len(f), 1), float(sk), dtype=torch.float32)).numpy().astype(float)
    return z


def tune_pnp(den, op, Ft, rng, tikR):
    Gt, Mt = op.measure(Ft, SIG, rng)
    x0 = x0_estimate(op, Gt, Mt, tikR)
    best = (np.inf, None)
    for lam in (0.03, 0.1, 0.3, 1.0, 3.0):
        for s1 in (0.3, 1.0):
            e = rmse(pnp_hqs(den, op, Gt, Mt, SIG, lam, s1, x0), Ft).mean()
            if e < best[0]:
                best = (e, (lam, s1))
    return best[1]


# ------------------------------------------------------------------ a full method suite for one task
class Suite:
    """Tunes / trains all methods for one task at the nominal operator (sigma = 0.1)."""

    def __init__(self, kind, Ftr_all, seed, steps=None, ablation=False, denoiser=None, cheap=False):
        self.kind, self.n = kind, Ftr_all.shape[1]
        cfg = dict(CFG)
        if steps:
            cfg["steps"] = steps
        self.cfg = cfg
        Ftr, Fval, perm = split_val(Ftr_all, seed)
        op = make_op(kind, self.n, cfg)
        self.op = op
        rng = np.random.default_rng(seed + 7)
        Ft = Ftr_all[perm[:cfg["tune_n"]]]
        Gt, Mt = op.measure(Ft, SIG, rng)
        grid = [(l, o) for o in (1, 2) for l in cfg["tik_grid"]]
        self.lam = grid[int(np.argmin([rmse(tikhonov(op, Gt, Mt, p), Ft).mean() for p in grid]))]
        self.lam_tv = None if cheap else cfg["tv_grid"][int(np.argmin(
            [rmse(tv_admm(op, Gt, Mt, l, cfg["admm_tune_iters"], cfg["rho"]), Ft).mean() for l in cfg["tv_grid"]]))]
        self.tikR = tikhonov_matrix(op, self.lam) if op.fixed else None
        self.gp = GaussPrior().fit(Ftr_all)
        self.ridge = None if cheap else RidgeMap().fit(op, Ftr, Fval, SIG, np.random.default_rng(seed + 5))
        gaps = kind == "gaps"
        self.nets = {}
        for name, mk in [("LGD", lambda: LGD(gaps, cfg["hidden"], cfg["lgd_K"])),
                         ("PostCNN", lambda: PostCNN(gaps, cfg["hidden"])),
                         ("DirectCNN", lambda: DirectCNN(gaps, cfg["hidden"]))]:
            torch.manual_seed(seed)
            self.nets[name] = train_net(mk(), op, Ftr, Fval, SIG, np.random.default_rng(seed + 9), self.tikR, cfg)
        self.abl = {}
        if ablation:
            for v, (blind, loopA) in {"LGD_noAinit": (True, True), "LGD_noA": (True, False)}.items():
                torch.manual_seed(seed)
                net = LGDAblate(gaps, cfg["hidden"], cfg["lgd_K"], loopA)
                self.abl[v] = (train_generic(net, op, Ftr, Fval, np.random.default_rng(seed + 9),
                                             make_init(op, self.tikR, blind), cfg["steps"]), blind)
        self.den, self.pnp_par = denoiser, None
        if denoiser is not None:
            self.pnp_par = tune_pnp(denoiser, op, Ft[:100], np.random.default_rng(seed + 21), self.tikR)

    def predict(self, op_e, G, M, sigma=SIG, assumed_op=None):
        """Reconstruct with every method. assumed_op: operator the methods believe in (misspecification)."""
        op_m = assumed_op if assumed_op is not None else op_e
        tikR = tikhonov_matrix(op_m, self.lam) if op_m.fixed else None
        out = {"Classical": naive(op_m, G, M) if self.kind != "deconv" else None,
               "Tikhonov": tikhonov(op_m, G, M, self.lam),
               "GaussPrior": self.gp.predict(op_m, G, M, sigma)}
        if self.lam_tv is not None:
            out["TV"] = tv_admm(op_m, G, M, self.lam_tv, CFG["admm_iters"], CFG["rho"])
        if self.ridge is not None:
            out["Ridge"] = self.ridge.predict(op_m, G, M)
        for k, net in self.nets.items():
            out[k] = net_predict(net, op_m, G, M, tikR)
        for k, (net, blind) in self.abl.items():
            out[k] = predict_generic(net, op_m, G, M, make_init(op_m, tikR, blind))
        if self.den is not None:
            out["PnP"] = pnp_hqs(self.den, op_m, G, M, sigma, *self.pnp_par, x0_estimate(op_m, G, M, tikR))
        return {k: v for k, v in out.items() if v is not None}


def scores(out, F, M=None):
    r = {k: float(rmse(v, F).mean()) for k, v in out.items()}
    if M is not None:
        r = {"full": r, "missing": {k: float(missing_rmse(v, F, M).mean()) for k, v in out.items()}}
    return r


# ------------------------------------------------------------------ part N
def obs_stats(op, G, M):
    """Mean and std of the observed values only (no access to the clean series)."""
    if op.kind == "gaps":
        m = np.array([g[mm].mean() for g, mm in zip(G, M)])
        s = np.array([g[mm].std() for g, mm in zip(G, M)])
    else:
        m, s = G.mean(1), G.std(1)
    return m, np.maximum(s, 1e-8)


def run_N(name):
    seed = zlib.crc32(("N" + name).encode()) % (2 ** 31)
    Ftr_all, Fte, _ = load(name, np.random.default_rng(seed))
    out = dict(dataset=name, n=Ftr_all.shape[1], tasks={})
    for kind in bench.TASKS:
        S = Suite(kind, Ftr_all, seed)
        op = S.op
        # calibration factor c = median sd(f)/sd(observations), from simulated TRAINING observations only
        Gc, Mc = op.measure(Ftr_all[:500], SIG, np.random.default_rng(seed + 31))
        c = float(np.median(1.0 / obs_stats(op, Gc, Mc)[1]))
        # test observations of series with an arbitrary per-series offset and scale (raw units)
        trng = np.random.default_rng(seed + 11)
        a = np.exp(trng.uniform(np.log(0.2), np.log(5.0), (len(Fte), 1)))
        b = trng.uniform(-10, 10, (len(Fte), 1))
        Fraw = a * Fte + b
        G0, M = op.measure(Fte, SIG, trng)                      # observations in clean-z units
        Graw = a * G0 + (b if op.kind != "gaps" else b * M)      # same observations in raw units
        r = {"c": c}
        # (i) oracle: clean statistics (the paper's protocol)
        r["oracle"] = scores(S.predict(op, G0, M), Fte, M if kind == "gaps" else None)
        for lab, cc in (("obs", 1.0), ("obs_cal", c)):
            m, s = obs_stats(op, Graw, M)
            s = s * cc
            Gn = (Graw - m[:, None]) / s[:, None]
            if op.kind == "gaps":
                Gn = Gn * M
            sig_n = float(np.median(SIG * a[:, 0] / s))          # noise std known in raw units -> normalised units
            rec = S.predict(op, Gn, M, sigma=sig_n)
            # back to raw units, then score relative to each clean series' own std (= NRMSE as in the paper)
            rec = {k: ((v * s[:, None] + m[:, None]) - b) / a for k, v in rec.items()}
            r[lab] = scores(rec, Fte, M if kind == "gaps" else None)
            r[lab + "_scale_err"] = float(np.median(np.abs(np.log(s / a[:, 0]))))
        # (iii) matched: training series normalised exactly as test series will be (statistics of one simulated
        #     observation of each training series), so that the learned priors do not rely on the oracle constraint
        #     mean(f) = 0, sd(f) = 1.  All methods are re-tuned / re-trained on these series.
        Gs, Ms = op.measure(Ftr_all, SIG, np.random.default_rng(seed + 33))
        ms, ss = obs_stats(op, Gs, Ms)
        ss = ss * c
        S2 = Suite(kind, (Ftr_all - ms[:, None]) / ss[:, None], seed)
        m, s = obs_stats(op, Graw, M)
        s = s * c
        Gn = (Graw - m[:, None]) / s[:, None]
        if op.kind == "gaps":
            Gn = Gn * M
        rec = S2.predict(op, Gn, M, sigma=float(np.median(SIG * a[:, 0] / s)))
        rec = {k: ((v * s[:, None] + m[:, None]) - b) / a for k, v in rec.items()}
        r["matched"] = scores(rec, Fte, M if kind == "gaps" else None)
        out["tasks"][kind] = r
    return out


# ------------------------------------------------------------------ part R
def run_R(name):
    seed = zlib.crc32(("R" + name).encode()) % (2 ** 31)
    out = dict(dataset=name, prep={})
    for how in ("linear", "antialias", "orig"):
        Ftr_all, Fte, n0 = load(name, np.random.default_rng(seed), how=how)
        if n0 <= 256:
            return dict(dataset=name, skipped=f"length {n0} <= 256")
        r = dict(n=Ftr_all.shape[1], tasks={})
        for kind in bench.TASKS:
            S = Suite(kind, Ftr_all, seed)
            G, M = S.op.measure(Fte, SIG, np.random.default_rng(seed + 11))
            r["tasks"][kind] = scores(S.predict(S.op, G, M), Fte, M if kind == "gaps" else None)
            if kind == "deconv":
                op_m = deconv_op(S.n, 1.5)
                G2, _ = op_m.measure(Fte, SIG, np.random.default_rng(seed + 13))
                r["tasks"]["deconv_shift"] = scores(S.predict(op_m, G2, None), Fte)
        out["prep"][how] = r
        out["n_orig"] = n0
    return out


# ------------------------------------------------------------------ part K
WIDTHS = [0.5, 0.75, 1.25, 1.5, 2.0]
MISSPEC = [-0.2, -0.1, 0.1, 0.2]


def run_K(name):
    seed = zlib.crc32(("K" + name).encode()) % (2 ** 31)
    Ftr_all, Fte, _ = load(name, np.random.default_rng(seed))
    n = Ftr_all.shape[1]
    den = train_denoiser(Ftr_all, np.random.default_rng(seed + 41), 1000)
    S = Suite("deconv", Ftr_all, seed, ablation=True, denoiser=den, cheap=True)
    out = dict(dataset=name, n=n, known={}, misspec={})
    G, _ = S.op.measure(Fte, SIG, np.random.default_rng(seed + 11))
    out["nominal"] = scores(S.predict(S.op, G, None), Fte)
    for f in WIDTHS:
        op = deconv_op(n, f)
        G, _ = op.measure(Fte, SIG, np.random.default_rng(seed + 13))
        out["known"][str(f)] = scores(S.predict(op, G, None), Fte)
    for d in MISSPEC:                                            # nominal kernel assumed, true kernel differs
        op_true = deconv_op(n, 1 + d)
        G, _ = op_true.measure(Fte, SIG, np.random.default_rng(seed + 17))
        out["misspec"][str(d)] = scores(S.predict(op_true, G, None, assumed_op=S.op), Fte)
    # combined: kernel changed to 1.5 w, but estimated with a +-10 % error
    out["shift_misspec"] = {}
    for d in (-0.1, 0.1):
        op_true = deconv_op(n, 1.5)
        G, _ = op_true.measure(Fte, SIG, np.random.default_rng(seed + 19))
        out["shift_misspec"][str(d)] = scores(S.predict(op_true, G, None, assumed_op=deconv_op(n, 1.5 * (1 + d))), Fte)
    return out


# ------------------------------------------------------------------ part P
def saits_brits(Ftr, Fval, op, G_list, M_list, seed, epochs=40):
    """Train SAITS and BRITS (PyPOTS) on training series with block gaps; impute the test observations."""
    from pypots.imputation import SAITS, BRITS
    rng = np.random.default_rng(seed + 51)
    n = Ftr.shape[1]
    Frep = np.repeat(Ftr, 5, axis=0)[:4000]
    Gt, Mt = op.measure(Frep, SIG, rng)
    Xt = np.where(Mt, Gt, np.nan)[..., None]
    Gv, Mv = op.measure(Fval, SIG, rng)
    Xv = np.where(Mv, Gv, np.nan)[..., None]
    val = {"X": Xv, "X_ori": Fval[..., None]}
    models = {
        "SAITS": SAITS(n_steps=n, n_features=1, n_layers=2, d_model=64, n_heads=4, d_k=16, d_v=16, d_ffn=128,
                       dropout=0.1, epochs=150, patience=15, batch_size=32, device="cpu"),
        "BRITS": BRITS(n_steps=n, n_features=1, rnn_hidden_size=64, epochs=epochs, patience=5, batch_size=32,
                       device="cpu"),
    }
    res, tsec = {}, {}
    for k, m in models.items():
        torch.manual_seed(seed)
        t0 = time.time()
        m.fit({"X": Xt}, val)
        tsec[k] = time.time() - t0
        res[k] = [m.impute({"X": np.where(MM, GG, np.nan)[..., None]})[..., 0] for GG, MM in zip(G_list, M_list)]
    return res, tsec


def run_P(name, with_pypots=True):
    seed = zlib.crc32(("P" + name).encode()) % (2 ** 31)
    Ftr_all, Fte, _ = load(name, np.random.default_rng(seed))
    n = Ftr_all.shape[1]
    t0 = time.time()
    den = train_denoiser(Ftr_all, np.random.default_rng(seed + 41), 1000)
    out = dict(dataset=name, n=n, denoiser_train_s=time.time() - t0, tasks={})
    for kind in bench.TASKS:
        S = Suite(kind, Ftr_all, seed, denoiser=den, cheap=True)
        r = {"pnp_par": list(S.pnp_par)}
        G, M = S.op.measure(Fte, SIG, np.random.default_rng(seed + 11))
        rec = S.predict(S.op, G, M)
        if kind in ("deconv", "gaps"):
            op_m = make_op(kind, n, CFG, "mismatch")
            G2, M2 = op_m.measure(Fte, SIG, np.random.default_rng(seed + 13))
            rec2 = S.predict(op_m, G2, M2)
        if kind == "gaps" and with_pypots:
            Ftr, Fval, _ = split_val(Ftr_all, seed)
            extra, tsec = saits_brits(Ftr, Fval, S.op, [G, G2], [M, M2], seed)
            for k, (a, b) in extra.items():
                rec[k], rec2[k] = a, b
            r["train_s"] = tsec
        r["nominal"] = scores(rec, Fte, M if kind == "gaps" else None)
        if kind in ("deconv", "gaps"):
            r["shift"] = scores(rec2, Fte, M2 if kind == "gaps" else None)
        out["tasks"][kind] = r
    return out


# ------------------------------------------------------------------ part T
def run_T(name):
    out = dict(dataset=name, tasks={})
    base = zlib.crc32(("T" + name).encode()) % (2 ** 31)
    Ftr_all, Fte, _ = load(name, np.random.default_rng(base))
    for kind in ("gaps", "down"):
        r = {}
        for s in range(3):
            for steps in (500, 2000):
                S = Suite(kind, Ftr_all, base + 1000 * s, steps=steps, cheap=True)
                G, M = S.op.measure(Fte, SIG, np.random.default_rng(base + 11))
                r[f"s{s}_{steps}"] = scores(S.predict(S.op, G, M), Fte)
        out["tasks"][kind] = r
    return out


def main():
    torch.set_num_threads(1)
    part, wid, nw = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    sel = sys.argv[4] if len(sys.argv) > 4 else None                 # "all" = the 113 usable datasets
    names = SP_SETS if sel is None else (bench.usable() if sel == "all" else sel.split(","))
    od = os.path.join(RES, part)
    os.makedirs(od, exist_ok=True)
    fn = dict(N=run_N, R=run_R, K=run_K, P=run_P, T=run_T)[part]
    for i, name in enumerate(names):
        if i % nw != wid:
            continue
        path = os.path.join(od, f"{name}.json")
        if os.path.exists(path):
            continue
        t0 = time.time()
        try:
            res = fn(name)
            res["wall_s"] = time.time() - t0
            json.dump(res, open(path, "w"))
            print(part, name, f"{time.time() - t0:.0f}s", flush=True)
        except Exception as exc:
            import traceback
            traceback.print_exc()
            print(part, name, "FAILED", repr(exc), flush=True)


if __name__ == "__main__":
    main()
