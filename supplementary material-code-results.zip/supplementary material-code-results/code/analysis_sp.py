"""Tables and figure for the additional studies (bench_sp.py).  python analysis_sp.py
Writes results/tables/sp_*.csv and results/tables/fig_kernel_sweep.(png|pdf)."""
import os
import glob
import json
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import paths

SP = os.path.join(paths.RESULTS, "sp")
OUT = paths.OUT
TASKS = ["denoise", "deconv", "gaps", "down"]
LAB = dict(Tikhonov="Tikhonov", TV="TV", GaussPrior="Learned Gaussian prior", LGD="Unrolled LGD",
           PostCNN="CNN post-processing", DirectCNN="Fully learned CNN", Ridge="Ridge map", PnP="Plug-and-play HQS",
           SAITS="SAITS", BRITS="BRITS", LGD_noAinit="LGD, operator-free init", LGD_noA="LGD, operator-free",
           Classical="Classical")


def load(part):
    return {os.path.basename(f)[:-5]: json.load(open(f)) for f in sorted(glob.glob(os.path.join(SP, part, "*.json")))}


def gm(x):
    x = np.asarray(x, float)
    return float(np.exp(np.mean(np.log(x))))


def full(d):
    return d["full"] if "full" in d else d


def pval(a, b):
    a, b = np.asarray(a), np.asarray(b)
    if len(a) < 6 or np.allclose(a, b):
        return np.nan
    return float(wilcoxon(a, b).pvalue)


# ------------------------------------------------------------- N
def table_N():
    R = load("N")
    rows = []
    for t in TASKS:
        meths = list(full(R[next(iter(R))]["tasks"][t]["oracle"]).keys())
        for m in meths:
            o = [full(r["tasks"][t]["oracle"])[m] for r in R.values()]
            row = dict(task=t, method=m, n_datasets=len(R))
            for lab in ("obs", "obs_cal", "matched"):
                e = [full(r["tasks"][t][lab])[m] for r in R.values()]
                tk = [full(r["tasks"][t][lab])["Tikhonov"] for r in R.values()]
                row[f"{lab}_over_oracle"] = gm(np.array(e) / np.array(o))
                row[f"{lab}_vs_tik"] = gm(np.array(e) / np.array(tk))
            tko = [full(r["tasks"][t]["oracle"])["Tikhonov"] for r in R.values()]
            row["oracle_vs_tik"] = gm(np.array(o) / np.array(tko))
            rows.append(row)
    df = pd.DataFrame(rows)
    sc = [dict(task=t, scale_err_obs=np.median([r["tasks"][t]["obs_scale_err"] for r in R.values()]),
               scale_err_cal=np.median([r["tasks"][t]["obs_cal_scale_err"] for r in R.values()]),
               c=np.median([r["tasks"][t]["c"] for r in R.values()])) for t in TASKS]
    df.to_csv(os.path.join(OUT, "sp_normalisation.csv"), index=False)
    pd.DataFrame(sc).to_csv(os.path.join(OUT, "sp_normalisation_scale.csv"), index=False)
    return df, pd.DataFrame(sc)


# ------------------------------------------------------------- R
def table_R():
    R = {k: v for k, v in load("R").items() if "prep" in v}
    rows = []
    for t in TASKS + ["deconv_shift"]:
        meths = list(full(R[next(iter(R))]["prep"]["linear"]["tasks"][t]).keys())
        for m in meths:
            row = dict(task=t, method=m, n_datasets=len(R))
            for how in ("linear", "antialias", "orig"):
                e = [full(r["prep"][how]["tasks"][t])[m] for r in R.values()]
                tk = [full(r["prep"][how]["tasks"][t])["Tikhonov"] for r in R.values()]
                row[f"{how}_vs_tik"] = gm(np.array(e) / np.array(tk))
            rows.append(row)
    df = pd.DataFrame(rows)
    # does the best method change?
    best = []
    for name, r in R.items():
        for t in TASKS:
            b = {how: min(full(r["prep"][how]["tasks"][t]).items(), key=lambda kv: kv[1])[0] for how in r["prep"]}
            best.append(dict(dataset=name, task=t, **b))
    df.to_csv(os.path.join(OUT, "sp_resampling.csv"), index=False)
    pd.DataFrame(best).to_csv(os.path.join(OUT, "sp_resampling_best.csv"), index=False)
    return df, pd.DataFrame(best)


# ------------------------------------------------------------- K
def table_K():
    R = load("K")
    names = list(R)
    meths = list(R[names[0]]["nominal"].keys())
    rows = []
    conds = [("nominal", lambda r: r["nominal"])]
    conds += [(f"known x{f}", (lambda f: lambda r: r["known"][f])(f)) for f in R[names[0]]["known"]]
    conds += [(f"misspec {float(d):+.0%}", (lambda d: lambda r: r["misspec"][d])(d)) for d in R[names[0]]["misspec"]]
    conds += [(f"x1.5, assumed {float(d):+.0%}", (lambda d: lambda r: r["shift_misspec"][d])(d))
              for d in R[names[0]]["shift_misspec"]]
    for c, get in conds:
        nom = {m: np.array([R[n]["nominal"][m] for n in names]) for m in meths}
        e = {m: np.array([get(R[n])[m] for n in names]) for m in meths}
        row = dict(condition=c, n_datasets=len(names))
        for m in meths:
            row[m] = gm(e[m] / nom[m])                       # degradation relative to the method's own nominal error
        row["init_effect"] = gm(e["LGD"] / e["LGD_noAinit"])  # operator-based vs operator-free initial estimate
        row["init_wins"] = int(np.sum(e["LGD"] < e["LGD_noAinit"]))
        row["LGD_vs_Direct"] = gm(e["LGD"] / e["DirectCNN"])
        row["PnP_vs_LGD"] = gm(e["PnP"] / e["LGD"])
        for m in meths:
            row["med_" + m] = float(np.median(e[m]))
        rows.append(row)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT, "sp_kernel.csv"), index=False)
    # figure: median NRMSE against width factor (known change) and against assumed-kernel error
    fig, ax = plt.subplots(1, 2, figsize=(9.6, 3.6))
    show = ["Tikhonov", "GaussPrior", "LGD", "LGD_noAinit", "LGD_noA", "DirectCNN", "PnP"]
    sty = dict(Tikhonov=("#4b3aa6", "s", "-"), GaussPrior=("#2a78d6", "o", "-"), LGD=("#e8663a", "o", "-"),
               LGD_noAinit=("#e8663a", "^", "--"), LGD_noA=("#e8663a", "v", ":"), DirectCNN=("#1aa979", "D", "-"),
               PnP=("#8a5a00", "P", "-"))
    fac = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]
    for m in show:
        y = [gm([R[n]["known"][str(f)][m] if f != 1.0 else R[n]["nominal"][m] for n in names]) for f in fac]
        c, mk, ls = sty[m]
        ax[0].plot(fac, y, ls, color=c, marker=mk, label=LAB[m], ms=5, lw=1.5)
    ax[0].set_xlabel("Kernel width at test / training width (new kernel known)")
    ax[0].set_ylabel("Geometric-mean NRMSE")
    ax[0].set_title("(a) Known change of the sensor kernel", fontsize=10)
    dd = [-0.2, -0.1, 0.0, 0.1, 0.2]
    for m in show:
        y = [gm([R[n]["misspec"][str(d)][m] if d != 0 else R[n]["nominal"][m] for n in names]) for d in dd]
        c, mk, ls = sty[m]
        ax[1].plot([100 * d for d in dd], y, ls, color=c, marker=mk, ms=5, lw=1.5)
    ax[1].set_xlabel("Error of true kernel width relative to assumed width (%)")
    ax[1].set_title("(b) Misspecified kernel", fontsize=10)
    for a in ax:
        a.grid(alpha=0.3)
        a.spines[["top", "right"]].set_visible(False)
    fig.legend(loc="lower center", ncol=4, frameon=False, fontsize=8.5)
    fig.tight_layout(rect=(0, 0.13, 1, 1))
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"fig_kernel_sweep.{ext}"), dpi=300)
    return df


# ------------------------------------------------------------- P
def table_P():
    R = load("P")
    rows = []
    for t in TASKS:
        for cond in ("nominal", "shift"):
            rs = [r["tasks"][t] for r in R.values() if cond in r["tasks"][t]]
            if not rs:
                continue
            for metric in (("full", "missing") if t == "gaps" else ("full",)):
                get = (lambda d: d[metric]) if t == "gaps" else (lambda d: d)
                meths = list(get(rs[0][cond]).keys())
                E = {m: np.array([get(r[cond])[m] for r in rs]) for m in meths}
                ranks = pd.DataFrame(E).rank(axis=1).mean()
                for m in meths:
                    rows.append(dict(task=t, condition=cond, metric=metric, method=m, n_datasets=len(rs),
                                     ratio_vs_tik=gm(E[m] / E["Tikhonov"]), avg_rank=float(ranks[m]),
                                     ratio_vs_LGD=gm(E[m] / E["LGD"]), wins_vs_LGD=int(np.sum(E[m] < E["LGD"])),
                                     median=float(np.median(E[m]))))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT, "sp_baselines.csv"), index=False)
    return df


# ------------------------------------------------------------- T
def table_T():
    R = load("T")
    rows = []
    for t in ("gaps", "down"):
        for m in ("LGD", "PostCNN", "DirectCNN"):
            r500 = np.array([[R[n]["tasks"][t][f"s{s}_500"][m] for s in range(3)] for n in R])
            r2k = np.array([[R[n]["tasks"][t][f"s{s}_2000"][m] for s in range(3)] for n in R])
            gp = np.array([[R[n]["tasks"][t][f"s{s}_500"]["GaussPrior"] for s in range(3)] for n in R])
            tk = np.array([[R[n]["tasks"][t][f"s{s}_500"]["Tikhonov"] for s in range(3)] for n in R])
            rows.append(dict(task=t, method=m, n_datasets=len(R),
                             gain_2000_over_500=gm(r2k / r500),
                             ratio_vs_tik_500=gm(r500 / tk), ratio_vs_tik_2000=gm(r2k / tk),
                             seed_sd_ratio_500=float(np.mean(np.std(r500 / tk, axis=1))),
                             seed_sd_ratio_2000=float(np.mean(np.std(r2k / tk, axis=1))),
                             vs_GP_500=gm(r500 / gp), vs_GP_2000=gm(r2k / gp),
                             beats_GP_500=int(np.sum(r500 < gp)), beats_GP_2000=int(np.sum(r2k < gp)),
                             runs=int(r500.size)))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT, "sp_budget.csv"), index=False)
    return df


if __name__ == "__main__":
    pd.set_option("display.width", 250, "display.max_columns", 40, "display.precision", 3)
    for part, fn in (("N", table_N), ("R", table_R), ("K", table_K), ("P", table_P), ("T", table_T)):
        if glob.glob(os.path.join(SP, part, "*.json")):
            print("=" * 30, part)
            out = fn()
            for o in (out if isinstance(out, tuple) else (out,)):
                print(o.to_string())
