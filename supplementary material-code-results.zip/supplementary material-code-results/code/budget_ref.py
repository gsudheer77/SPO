import os, json, glob, numpy as np, pandas as pd
import paths
import extra
from bench import CFG, make_op, GaussPrior, rmse
rows=[]
for d in extra.BUDGET_SETS:
    Ftr,Fte,rng=extra.data(d)
    Ftr=Ftr[:CFG["max_train"]]
    for kind in ("gaps","down"):
        out=extra.fit_eval(kind,Ftr,Fte,rng,0,["Tikhonov","GaussPrior"])
        rows.append(dict(dataset=d,task=kind,**out))
R=pd.DataFrame(rows)
B=pd.DataFrame([json.load(open(p)) for p in glob.glob(os.path.join(paths.BUDGET, "*.json"))])
B2=B[B.x==2000].drop(columns="x"); B5=B[B.x==500].drop(columns="x")
M=R.merge(B2,on=["dataset","task"]).merge(B5,on=["dataset","task"],suffixes=("_2000","_500"))
M.to_csv(os.path.join(paths.OUT, "table_budget_full.csv"),index=False)
pd.set_option("display.width",200)
print(M.round(3).to_string())
for t in ("gaps","down"):
    x=M[M.task==t]
    for c in ["LGD_500","LGD_2000","PostCNN_2000","DirectCNN_2000"]:
        print(t,c,"GaussPrior better on",int((x.GaussPrior<x[c]).sum()),"of",len(x),"median ratio GP/net",round(float(np.median(x.GaussPrior/x[c])),3))
