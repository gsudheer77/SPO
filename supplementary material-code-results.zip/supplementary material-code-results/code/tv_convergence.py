"""Convergence and iteration sensitivity of the TV (ADMM) baseline.  Needs the UCR data.

    python tv_convergence.py all 4                        run on 4 processes (works on Windows, Linux, macOS)
    python tv_convergence.py <worker_id> <n_workers>      or start the workers yourself
    python tv_convergence.py summary                      -> results/tables/table_tv_convergence*.csv

The benchmark runs ADMM (rho = 1, splitting z = D1 f) for a fixed number of iterations, 100 while tuning
lambda and 200 at test time, without a stopping rule. For every dataset and task this script runs exactly
the same iterations, for every lambda of the tuning grid, on the 200 tuning series and on 300 test series
(fresh noise), and records after K in {50, 100, 200, 500, 1000} iterations
  * the NRMSE on the tuning and the test series,
  * the median relative primal and dual residuals  ||D f - z|| / max(||D f||, ||z||)  and
    rho ||D^T (z - z_prev)|| / ||rho D^T u||  (Boyd et al., 2011, Sec. 3.3).
It also evaluates bilevel-tuned Tikhonov (lambda and order from the main benchmark) on the same test series.
From this one can read (a) how far the benchmark's TV iterates are from convergence, (b) how the error of
the benchmark's lambda changes with K, and (c) how TV compares with Tikhonov when lambda is re-tuned for a
larger K. Results: results/tv_convergence/<dataset>.json. About 2-5 CPU-minutes per dataset.
"""
import os
import sys
import json
import glob
import zlib
import numpy as np
import pandas as pd

import paths
import ucr_io
from bench import CFG, prep, make_op, diff1, _tridiag_factor, _tridiag_solve, rmse, tikhonov

CHECK = [50, 100, 200, 500, 1000]
OUTD = os.path.join(paths.RESULTS, "tv_convergence")
os.makedirs(OUTD, exist_ok=True)


def tv_admm_trace(op, G, M, lam, iters, rho=1.0, F_true=None, checkpoints=(), split=None, F_parts=None):
    """Identical iterations to bench.tv_admm; additionally records error and residuals at checkpoints."""
    n = op.n
    D = diff1(n)
    if op.fixed:
        Minv = np.linalg.inv(op.A.T @ op.A + rho * D.T @ D)
        AtG = G @ op.A
        solve = lambda r: r @ Minv.T
    else:
        dtd = np.full(n, 2.0)
        dtd[0] = dtd[-1] = 1.0
        cp, den = _tridiag_factor(M + rho * dtd[None, :], -rho)
        AtG = M * G
        solve = lambda r: _tridiag_solve(cp, den, -rho, r)
    Z = np.zeros((len(G), n - 1))
    U = np.zeros_like(Z)
    trace = {}
    for k in range(1, iters + 1):
        F = solve(AtG + rho * (Z - U) @ D)
        DF = F @ D.T
        V = DF + U
        Z_old = Z
        Z = np.sign(V) * np.maximum(np.abs(V) - lam / rho, 0)
        U = U + DF - Z
        if k in checkpoints:
            nr = lambda X: np.linalg.norm(X, axis=1)
            prim = nr(DF - Z) / np.maximum(np.maximum(nr(DF), nr(Z)), 1e-12)
            dual = rho * nr((Z - Z_old) @ D) / np.maximum(rho * nr(U @ D), 1e-12)
            e = {}
            if F_true is not None:
                e["nrmse"] = float(rmse(F, F_true).mean())
            if F_parts is not None:
                e["nrmse_tune"] = float(rmse(F[:split], F_parts[0]).mean())
                e["nrmse_test"] = float(rmse(F[split:], F_parts[1]).mean())
                prim, dual = prim[split:], dual[split:]
            trace[k] = dict(**e, primal_res_median=float(np.median(prim)), primal_res_p95=float(np.quantile(prim, .95)),
                            dual_res_median=float(np.median(dual)), dual_res_p95=float(np.quantile(dual, .95)))
    return F, trace


def run_dataset(name, Ftr, Fte, tik_par, seed):
    rng = np.random.default_rng(seed)
    res = {"dataset": name, "n": int(Ftr.shape[1]), "tasks": {}}
    Ft = Ftr[:CFG["tune_n"]]
    for kind in ["denoise", "deconv", "gaps", "down"]:
        op = make_op(kind, Ftr.shape[1], CFG)
        Gt, Mt = op.measure(Ft, CFG["sigma"], rng)
        G, M = op.measure(Fte, CFG["sigma"], rng)
        Gall = np.vstack([Gt, G])
        Mall = np.vstack([Mt, M]) if Mt is not None else None
        nt = len(Ft)
        per_lam = {}
        for lam in CFG["tv_grid"]:
            _, tr = tv_admm_trace(op, Gall, Mall, lam, max(CHECK), CFG["rho"], None, CHECK, split=nt,
                                  F_parts=(Ft, Fte))
            per_lam[repr(lam)] = tr
        tik = float(rmse(tikhonov(op, G, M, tuple(tik_par[kind])), Fte).mean())
        res["tasks"][kind] = dict(tikhonov_test=tik, per_lambda=per_lam)
    return res


def datasets():
    meta = pd.read_csv(paths.META)
    return sorted(meta[(meta.equal.astype(str) == "True") & (meta.has_nan.astype(str) == "False")].name)


def worker(wid, nw):
    for i, name in enumerate(datasets()):
        out = os.path.join(OUTD, f"{name}.json")
        if i % nw != wid or os.path.exists(out):
            continue
        Xtr, Xte, _ = ucr_io.load(name)
        Ftr, Fte = prep(Xtr, CFG["max_len"]), prep(Xte, CFG["max_len"])
        seed = zlib.crc32(("tvconv" + name).encode()) % (2 ** 31)
        rng = np.random.default_rng(seed)
        Ftr = Ftr[:CFG["max_train"]]
        Fte = Fte[rng.choice(len(Fte), min(300, len(Fte)), replace=False)]
        main = json.load(open(os.path.join(paths.MAIN, f"{name}.json")))
        tik = {t: main["tasks"][t]["Tikhonov"]["lambda"] for t in main["tasks"]}
        r = run_dataset(name, Ftr, Fte, tik, seed + 1)
        for t in r["tasks"]:
            r["tasks"][t]["lambda_main"] = main["tasks"][t]["TV"]["lambda"]
        json.dump(r, open(out, "w"))
        print(name, flush=True)


def summary():
    rows, sel = [], []
    for p in sorted(glob.glob(os.path.join(OUTD, "*.json"))):
        r = json.load(open(p))
        for t, v in r["tasks"].items():
            P = v["per_lambda"]
            lm = repr(v["lambda_main"])
            # lambda chosen as in the benchmark (100 tuning iterations) and re-tuned at K iterations
            pick = lambda K: min(P, key=lambda l: P[l][str(K)]["nrmse_tune"])
            for K in CHECK:
                rows.append(dict(dataset=r["dataset"], task=t, iters=K,
                                 test_main_lambda=P[lm][str(K)]["nrmse_test"],
                                 primal=P[lm][str(K)]["primal_res_median"], dual=P[lm][str(K)]["dual_res_median"],
                                 test_retuned=P[pick(K)][str(K)]["nrmse_test"], lambda_retuned=float(pick(K)),
                                 tikhonov=v["tikhonov_test"]))
    D = pd.DataFrame(rows)
    ref = D[D.iters == 200].set_index(["dataset", "task"]).test_main_lambda
    D["rel_change_vs_200_pct"] = 100 * (D.set_index(["dataset", "task"]).test_main_lambda.values /
                                       ref.reindex(pd.MultiIndex.from_frame(D[["dataset", "task"]])).values - 1)
    from scipy import stats
    out = []
    for (t, K), x in D.groupby(["task", "iters"]):
        w = x.test_retuned < x.tikhonov
        out.append(dict(task=t, iters=K, n_datasets=len(x),
                        median_primal_res=x.primal.median(), median_dual_res=x.dual.median(),
                        median_abs_change_vs_200_pct=x.rel_change_vs_200_pct.abs().median(),
                        p90_abs_change_vs_200_pct=x.rel_change_vs_200_pct.abs().quantile(.9),
                        tv_retuned_beats_tik=int(w.sum()),
                        gmean_ratio_tv_retuned_vs_tik=float(np.exp(np.mean(np.log(x.test_retuned / x.tikhonov)))),
                        p_wilcoxon=stats.wilcoxon(x.test_retuned, x.tikhonov).pvalue if len(x) > 5 else np.nan))
    S = pd.DataFrame(out)
    D.to_csv(os.path.join(paths.OUT, "table_tv_convergence_raw.csv"), index=False)
    S.to_csv(os.path.join(paths.OUT, "table_tv_convergence.csv"), index=False)
    pd.set_option("display.width", 220)
    print(S.round(4).to_string(index=False))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "summary":
        summary()
    elif len(sys.argv) > 1 and sys.argv[1] == "all":
        import multiprocessing as mp
        nw = int(sys.argv[2]) if len(sys.argv) > 2 else max(1, mp.cpu_count() // 2)
        ps = [mp.Process(target=worker, args=(w, nw)) for w in range(nw)]
        [p.start() for p in ps]; [p.join() for p in ps]
        summary()
    else:
        worker(int(sys.argv[1]), int(sys.argv[2]))
