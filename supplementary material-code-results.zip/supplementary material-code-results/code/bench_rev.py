"""Revision experiments requested in peer review.

  python bench_rev.py A <worker> <n_workers>   all 113 datasets: tuning-order sensitivity, coverage curve,
                                               missing-region errors for closed-form methods
  python bench_rev.py B <worker> <n_workers>   40 stratified datasets: matched 2x2 operator-access ablation,
                                               paired nominal/mismatch absolute errors, missing-region errors
  python bench_rev.py C <worker> <n_workers>   training-size sweep with 3 subset/training seeds (gap filling)

  Optional: <dataset list or "all"> [<output subfolder>], e.g.
  python bench_rev.py B 0 2 all                                  matched ablation on all 113 datasets
  python bench_rev.py C 0 2 FordB,HandOutlines,NonInvasiveFetalECGThorax1,NonInvasiveFetalECGThorax2,PhalangesOutlinesCorrect C_extended_5
"""
import os
import sys
import json
import time
import zlib
import numpy as np
import torch
import torch.nn as nn
from scipy import stats

import ucr_io
import bench
from bench import (CFG, prep, make_op, naive, tikhonov, tikhonov_matrix, tv_admm, rmse, GaussPrior, RidgeMap,
                   PostCNN, DirectCNN, conv_stack, TorchOp, train_net, net_predict, x0_estimate)

HERE = os.path.dirname(os.path.abspath(__file__))
import paths
RES = paths.REV
LEVELS = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99]
TASKS3 = ["deconv", "gaps", "down"]


def load_data(name, rng):
    Xtr, Xte, meta, ytr, yte = ucr_io.load(name, with_labels=True)
    Ftr, Fte = prep(Xtr, CFG["max_len"]), prep(Xte, CFG["max_len"])
    if len(Ftr) > CFG["max_train"]:
        i = rng.choice(len(Ftr), CFG["max_train"], replace=False)
        Ftr = Ftr[i]
    if len(Fte) > CFG["max_test"]:
        i = rng.choice(len(Fte), CFG["max_test"], replace=False)
        Fte = Fte[i]
    return Ftr, Fte


def tune_tik(op, Ft, rng):
    Gt, Mt = op.measure(Ft, CFG["sigma"], rng)
    grid = [(l, o) for o in (1, 2) for l in CFG["tik_grid"]]
    return grid[int(np.argmin([rmse(tikhonov(op, Gt, Mt, p), Ft).mean() for p in grid]))], Gt, Mt


def tune_tv(op, Ft, Gt, Mt):
    e = [rmse(tv_admm(op, Gt, Mt, l, CFG["admm_tune_iters"], CFG["rho"]), Ft).mean() for l in CFG["tv_grid"]]
    return CFG["tv_grid"][int(np.argmin(e))]


def missing_rmse(Fh, F, M):
    """Per-series RMSE over missing points only (gap filling)."""
    miss = ~M
    return np.sqrt(((Fh - F) ** 2 * miss).sum(1) / np.maximum(miss.sum(1), 1))


# ---------------------------------------------------------------- A
def run_A(name):
    seed = zlib.crc32(("A" + name).encode()) % (2 ** 31)
    rng = np.random.default_rng(seed)
    Ftr, Fte = load_data(name, rng)
    n = Ftr.shape[1]
    out = dict(dataset=name, n_train=len(Ftr), tasks={})
    gp = GaussPrior().fit(Ftr)
    perm = np.random.default_rng(seed + 1).permutation(len(Ftr))
    for kind in bench.TASKS:
        op = make_op(kind, n, CFG)
        r = {}
        # tuning on the first 200 series (as in the main benchmark) vs a random 200
        tuning = {}
        for lab, idx in [("first", np.arange(min(200, len(Ftr)))), ("random", perm[:200])]:
            trng = np.random.default_rng(seed + 7)
            lam, Gt, Mt = tune_tik(op, Ftr[idx], trng)
            lam_tv = tune_tv(op, Ftr[idx], Gt, Mt)
            tuning[lab] = (lam, lam_tv)
        G, M = op.measure(Fte, CFG["sigma"], np.random.default_rng(seed + 11))
        for lab, (lam, lam_tv) in tuning.items():
            Ft_h = tikhonov(op, G, M, lam)
            Tv_h = tv_admm(op, G, M, lam_tv, CFG["admm_iters"], CFG["rho"])
            r[f"tik_{lab}"] = float(rmse(Ft_h, Fte).mean())
            r[f"tv_{lab}"] = float(rmse(Tv_h, Fte).mean())
            r[f"tik_{lab}_par"] = [float(lam[0]), int(lam[1])]
            r[f"tv_{lab}_par"] = float(lam_tv)
            if kind == "gaps" and lab == "random":
                r["tik_missing"] = float(missing_rmse(Ft_h, Fte, M).mean())
                r["tv_missing"] = float(missing_rmse(Tv_h, Fte, M).mean())
        mu, var = gp.predict(op, G, M, CFG["sigma"], want_var=True)
        z = np.abs(mu - Fte) / np.sqrt(var)
        r["gp_nrmse"] = float(rmse(mu, Fte).mean())
        r["coverage"] = {str(a): float(np.mean(z <= stats.norm.ppf(0.5 + a / 2))) for a in LEVELS}
        # per-dataset PIT-style summary: mean |z| vs expected sqrt(2/pi)
        r["mean_abs_z"] = float(np.mean(z))
        if kind == "gaps":
            r["gp_missing"] = float(missing_rmse(mu, Fte, M).mean())
            r["classical_missing"] = float(missing_rmse(naive(op, G, M), Fte, M).mean())
            r["missing_frac"] = float((~M).mean())
            r["coverage_missing"] = {str(a): float(np.mean(z[~M] <= stats.norm.ppf(0.5 + a / 2))) for a in LEVELS}
        out["tasks"][kind] = r
    return out


# ---------------------------------------------------------------- B: matched ablation
class LGDAblate(nn.Module):
    """Same unrolled architecture as LGD; operator access switched on/off in the loop.

    loop_A=True : data-consistency channel A^T(A f - g)              (uses the operator)
    loop_A=False: data-consistency channel f - g_tilde               (operator replaced by identity on the grid)
    The initial estimate is supplied by the caller (operator-based or operator-free)."""

    def __init__(self, gaps, h, K, loop_A):
        super().__init__()
        self.gaps, self.loop_A = gaps, loop_A
        c = 3 if gaps else 2
        self.blocks = nn.ModuleList([conv_stack(c, h, (1, 2, 4)) for _ in range(K)])

    def forward(self, gup, x0, M, G, top):
        f = x0
        for blk in self.blocks:
            grad = top.adj(top.fwd(f, M) - G, M) if self.loop_A else f - gup
            parts = [f, grad] + ([M] if self.gaps else [])
            f = f + blk(torch.stack(parts, 1))[:, 0]
        return f


def make_init(op, tik_R, blind):
    if not blind:
        return lambda G, M: x0_estimate(op, G, M, tik_R)
    return lambda G, M: op.upsample(G)


def train_generic(net, op, Ftr, Fval, rng, init_fn, steps):
    """Like bench.train_net but with a pluggable initial estimate."""
    top = TorchOp(op)
    opt = torch.optim.Adam(net.parameters(), lr=CFG["lr"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, steps)
    t = lambda a: torch.tensor(a, dtype=torch.float32)

    def batch(F, r):
        G, M = op.measure(F, CFG["sigma"], r)
        return t(op.upsample(G)), t(init_fn(G, M)), (t(M) if M is not None else None), t(G)

    vb = batch(Fval, np.random.default_rng(12345))
    Fv = t(Fval)
    best, best_state = np.inf, None
    for step in range(1, steps + 1):
        F = Ftr[rng.integers(0, len(Ftr), CFG["batch"])]
        loss = torch.mean((net(*batch(F, rng), top) - t(F)) ** 2)
        opt.zero_grad()
        loss.backward()
        opt.step()
        sched.step()
        if step % CFG["eval_every"] == 0 or step == steps:
            with torch.no_grad():
                v = torch.mean((net(*vb, top) - Fv) ** 2).item()
            if v < best:
                best, best_state = v, {k: x.clone() for k, x in net.state_dict().items()}
    net.load_state_dict(best_state)
    return net


def predict_generic(net, op, G, M, init_fn):
    top = TorchOp(op)
    t = lambda a: torch.tensor(a, dtype=torch.float32)
    with torch.no_grad():
        return net(t(op.upsample(G)), t(init_fn(G, M)), t(M) if M is not None else None, t(G), top).numpy()


def run_B(name):
    seed = zlib.crc32(("B" + name).encode()) % (2 ** 31)
    rng = np.random.default_rng(seed)
    Ftr_all, Fte = load_data(name, rng)
    Fte = Fte[np.random.default_rng(seed + 3).permutation(len(Fte))[:300]]   # random 300, same for all methods
    n = Ftr_all.shape[1]
    perm = np.random.default_rng(seed + 1).permutation(len(Ftr_all))
    nval = max(2, int(round(0.1 * len(Ftr_all))))
    Fval, Ftr = Ftr_all[perm[:nval]], Ftr_all[perm[nval:]]
    gp = GaussPrior().fit(Ftr_all)
    out = dict(dataset=name, n_train=len(Ftr_all), n=n, tasks={})
    for kind in TASKS3:
        op = make_op(kind, n, CFG)
        lam, Gt, Mt = tune_tik(op, Ftr_all[perm[:200]], np.random.default_rng(seed + 7))
        lam_tv = tune_tv(op, Ftr_all[perm[:200]], Gt, Mt)
        tikR = tikhonov_matrix(op, lam) if op.fixed else None
        gaps = kind == "gaps"
        models, tsec = {}, {}
        ridge = RidgeMap().fit(op, Ftr, Fval, CFG["sigma"], np.random.default_rng(seed + 5))
        variants = {"LGD": (False, True), "LGD_noAloop": (False, False), "LGD_noAinit": (True, True),
                    "LGD_noA": (True, False)}
        for v, (blind_init, loop_A) in variants.items():
            torch.manual_seed(seed)                                   # identical initial weights
            net = LGDAblate(gaps, CFG["hidden"], CFG["lgd_K"], loop_A)
            init = make_init(op, tikR, blind_init)
            t0 = time.time()
            models[v] = (train_generic(net, op, Ftr, Fval, np.random.default_rng(seed + 9), init, CFG["steps"]), init)
            tsec[v] = time.time() - t0
        for v, cls in [("PostCNN", PostCNN), ("DirectCNN", DirectCNN)]:
            torch.manual_seed(seed)
            t0 = time.time()
            models[v] = (train_net(cls(gaps, CFG["hidden"]), op, Ftr, Fval, CFG["sigma"],
                                   np.random.default_rng(seed + 9), tikR, CFG), None)
            tsec[v] = time.time() - t0

        def evaluate(op_e, tikR_e, G, M):
            res = {"Classical": naive(op_e, G, M), "Tikhonov": tikhonov(op_e, G, M, lam),
                   "TV": tv_admm(op_e, G, M, lam_tv, CFG["admm_iters"], CFG["rho"]),
                   "GaussPrior": gp.predict(op_e, G, M, CFG["sigma"]), "Ridge": ridge.predict(op_e, G, M)}
            for v in variants:
                net, _ = models[v]
                blind_init = variants[v][0]
                res[v] = predict_generic(net, op_e, G, M, make_init(op_e, tikR_e, blind_init))
            for v in ("PostCNN", "DirectCNN"):
                res[v] = net_predict(models[v][0], op_e, G, M, tikR_e)
            return res

        r = {"train_s": tsec, "lambda": [float(lam[0]), int(lam[1])], "lambda_tv": lam_tv}
        G, M = op.measure(Fte, CFG["sigma"], np.random.default_rng(seed + 11))
        res = evaluate(op, tikR, G, M)
        r["nrmse"] = {k: float(rmse(v, Fte).mean()) for k, v in res.items()}
        if gaps:
            r["nrmse_missing"] = {k: float(missing_rmse(v, Fte, M).mean()) for k, v in res.items()}
        if kind in ("deconv", "gaps"):
            op_m = make_op(kind, n, CFG, "mismatch")
            tikR_m = tikhonov_matrix(op_m, lam) if op_m.fixed else None
            G2, M2 = op_m.measure(Fte, CFG["sigma"], np.random.default_rng(seed + 13))
            res2 = evaluate(op_m, tikR_m, G2, M2)
            r["nrmse_mismatch"] = {k: float(rmse(v, Fte).mean()) for k, v in res2.items()}
            if gaps:
                r["nrmse_missing_mismatch"] = {k: float(missing_rmse(v, Fte, M2).mean()) for k, v in res2.items()}
        out["tasks"][kind] = r
    return out


def subset_B():
    """40 datasets: 10 drawn at random from each quartile of training-set size (fixed seed)."""
    import csv
    names = bench.usable()
    rows = {r["name"]: r for r in csv.DictReader(open(paths.META))}
    ntr = np.array([min(int(rows[d]["n_train"]), CFG["max_train"]) for d in names])
    q = np.quantile(ntr, [0.25, 0.5, 0.75])
    bins = np.digitize(ntr, q)
    rng = np.random.default_rng(2026)
    pick = []
    for b in range(4):
        idx = np.flatnonzero(bins == b)
        pick += [names[i] for i in rng.choice(idx, 10, replace=False)]
    return sorted(pick)


# ---------------------------------------------------------------- C: seeded sweep
C_SETS = ["ElectricDevices", "Crop", "FordA", "StarLightCurves", "Wafer", "TwoPatterns"]
C_N = [16, 128, 1000]
C_SEEDS = [0, 1, 2]


def run_C(name, N, s):
    base = zlib.crc32(name.encode()) % (2 ** 31)
    rng = np.random.default_rng(base)
    Xtr, Xte, _ = ucr_io.load(name)
    Ftr, Fte = prep(Xtr, CFG["max_len"]), prep(Xte, CFG["max_len"])
    Fte = Fte[rng.choice(len(Fte), min(300, len(Fte)), replace=False)]
    srng = np.random.default_rng(1000 * s + 17)
    sub = Ftr[srng.choice(len(Ftr), N, replace=False)]           # different random subset per seed
    torch.manual_seed(s)
    n = sub.shape[1]
    op = make_op("gaps", n, CFG)
    nval = max(2, int(round(0.1 * N)))
    Fval, Ft = sub[:nval], sub[nval:]
    lam, _, _ = tune_tik(op, sub[:200], np.random.default_rng(s + 5))
    G, M = op.measure(Fte, CFG["sigma"], np.random.default_rng(7))
    out = dict(dataset=name, N=N, seed=s)
    out["Tikhonov"] = float(rmse(tikhonov(op, G, M, lam), Fte).mean())
    out["GaussPrior"] = float(rmse(GaussPrior().fit(sub).predict(op, G, M, CFG["sigma"]), Fte).mean())
    for v, mk in [("LGD", lambda: bench.LGD(True, CFG["hidden"], CFG["lgd_K"])), ("DirectCNN", lambda: DirectCNN(True, CFG["hidden"]))]:
        net = train_net(mk(), op, Ft, Fval, CFG["sigma"], srng, None, CFG)
        out[v] = float(rmse(net_predict(net, op, G, M, None), Fte).mean())
    return out


def main():
    torch.set_num_threads(1)
    mode, wid, nw = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    # optional 4th argument: dataset list ("all" = the 113 usable datasets, or comma-separated names);
    # optional 5th argument: output subfolder of results/revision (default: the mode letter).
    # Seeds depend only on the dataset name, so a dataset gives the same result in any list.
    sel = sys.argv[4] if len(sys.argv) > 4 else None
    names = None if sel is None else (bench.usable() if sel == "all" else sel.split(","))
    od = os.path.join(RES, sys.argv[5] if len(sys.argv) > 5 else mode)
    os.makedirs(od, exist_ok=True)
    if mode == "A":
        jobs = [(d,) for d in (names or bench.usable())]
    elif mode == "B":
        jobs = [(d,) for d in (names or subset_B())]
    else:
        jobs = [(d, N, s) for d in (names or C_SETS) for N in C_N for s in C_SEEDS]
    for i, job in enumerate(jobs):
        if i % nw != wid:
            continue
        path = os.path.join(od, "_".join(map(str, job)) + ".json")
        if os.path.exists(path):
            continue
        t0 = time.time()
        try:
            res = {"A": run_A, "B": run_B, "C": run_C}[mode](*job)
            res["wall_s"] = time.time() - t0
            json.dump(res, open(path, "w"))
            print(mode, job, f"{time.time() - t0:.0f}s", flush=True)
        except Exception as exc:
            import traceback
            traceback.print_exc()
            print(mode, job, "FAILED", repr(exc), flush=True)


if __name__ == "__main__":
    main()
