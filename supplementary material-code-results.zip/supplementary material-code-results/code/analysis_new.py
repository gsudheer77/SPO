"""Tables and figures of the Signal Processing submission that rest on the new experiments.

    python analysis_new.py

Reads results/revision/B (113 datasets), results/revision/C + C_extended_5, and results/sp/{K,N,P,R,T}
(written by bench_rev.py and bench_sp.py). Writes to results/tables/:
  table_ablation113.csv        Table 4 (matched ablation, Holm within condition) + architecture comparisons
  table_mismatch_paired113.csv Table S4;  table_missing_region113.csv  Table S5
  table_kernel.csv             Fig. 2 and Table S8 (kernel widths, misestimated and unsupplied changes)
  table_baselines.csv          Table 5 and Table S10 (PnP, SAITS, BRITS; 20 datasets)
  table_normalisation.csv      Table 6 and Table S9
  table_resampling.csv         Section 4.6 and Table S11 (37 long datasets)
  table_budget113.csv          Section 4.6 and Table S12 (500 vs 2,000 steps, 3 seeds, 113 datasets)
  table_sweep_seeds11.csv      Table S3 (seeded training-size sweep, 11 datasets)
  table_mechanism.csv          Table S13 and the diagnostics of Section 4.3
  fig_ablation113.(png|pdf)    Fig. 1;   fig_kernel.(png|pdf)  Fig. 2
  table_sensor.csv, table_iterates.csv, fig_iterates.(png|pdf)   optional study of bench_sensor.py (only if results/sp/S exists)
and prints the statistics quoted in the text. No data or PyTorch needed.
"""
import os
import glob
import json
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import paths
# style shared with analysis.py (copied so that this script needs neither PyTorch nor bench.py)
COLOR = {"GaussPrior": "#2a78d6", "LGD": "#eb6834", "DirectCNN": "#1baf7a", "PostCNN": "#eda100",
         "Ridge": "#e87ba4", "TV": "#008300", "Tikhonov": "#4a3aa7", "Classical": "#8a8984"}
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "legend.frameon": False,
                     "savefig.dpi": 300, "savefig.bbox": "tight"})


def holm(p):
    """Holm step-down adjusted p-values."""
    p = np.asarray(p, float)
    order, m, out, run = np.argsort(p), len(p), np.empty(len(p)), 0.0
    for i, j in enumerate(order):
        run = max(run, (m - i) * p[j])
        out[j] = min(1.0, run)
    return out

REV, SP, OUT = paths.REV, os.path.join(paths.RESULTS, "sp"), paths.OUT
pd.set_option("display.width", 220)
METH = ["Classical", "Tikhonov", "TV", "GaussPrior", "Ridge", "LGD", "PostCNN", "DirectCNN"]


def jl(folder):
    return [json.load(open(p)) for p in sorted(glob.glob(os.path.join(folder, "*.json")))]


def gm(x):
    return float(np.exp(np.mean(np.log(np.asarray(x, float)))))


def wil(a, b):
    """(datasets a better, b better, two-sided Wilcoxon p, geometric mean of a/b)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = a - b
    p = float(stats.wilcoxon(a, b).pvalue) if np.any(d != 0) else 1.0
    return int((d < 0).sum()), int((d > 0).sum()), p, gm(a / b)


def frame(recs, sel):
    return pd.DataFrame([dict(dataset=r["dataset"], **sel(r)) for r in recs]).set_index("dataset")


# ------------------------------------------------------------------ B: matched ablation, 113 datasets
def ablation():
    B = jl(os.path.join(REV, "B"))
    print(f"\n== Matched ablation: {len(B)} datasets")
    comps = [("loop | init uses A", "LGD", "LGD_noAloop"), ("loop | init without A", "LGD_noAinit", "LGD_noA"),
             ("init | loop uses A", "LGD", "LGD_noAinit"), ("init | loop without A", "LGD_noAloop", "LGD_noA"),
             ("both vs neither", "LGD", "LGD_noA")]
    rows = []
    for t in ["deconv", "gaps", "down"]:
        for cond in ["nrmse", "nrmse_mismatch", "nrmse_missing"]:
            if cond not in B[0]["tasks"][t]:
                continue
            W = frame(B, lambda b: b["tasks"][t][cond])
            for lab, a, c in comps:
                w = wil(W[a], W[c])
                rows.append(dict(kind="ablation", task=t, cond=cond, comparison=lab, gmean_ratio=w[3], with_better=w[0],
                                 without_better=w[1], p=w[2]))
            for a, c in [("LGD_noA", "DirectCNN"), ("LGD", "DirectCNN"), ("PostCNN", "DirectCNN"), ("GaussPrior", "LGD")]:
                w = wil(W[a], W[c])
                rows.append(dict(kind="architecture", task=t, cond=cond, comparison=f"{a} vs {c}", gmean_ratio=w[3],
                                 with_better=w[0], without_better=w[1], p=w[2]))
    T = pd.DataFrame(rows)
    T["p_holm"] = np.nan
    for cond in T.cond.unique():
        m = (T.cond == cond) & (T.kind == "ablation")
        T.loc[m, "p_holm"] = holm(T.loc[m, "p"].values)
    T.to_csv(os.path.join(OUT, "table_ablation113.csv"), index=False)
    print(T.round(5).to_string())

    # paired absolute errors under shift (Table S4) and missing-region errors (Table S5)
    rows = []
    for t in ["deconv", "gaps"]:
        W0, W1 = frame(B, lambda b: b["tasks"][t]["nrmse"]), frame(B, lambda b: b["tasks"][t]["nrmse_mismatch"])
        for m in METH:
            rows.append(dict(task=t, method=m, median_nominal=W0[m].median(), median_shift=W1[m].median(),
                             median_ratio=float(np.median(W1[m] / W0[m])), rank_shift=W1[METH].rank(axis=1).mean()[m]))
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "table_mismatch_paired113.csv"), index=False)
    Wm, Wf = frame(B, lambda b: b["tasks"]["gaps"]["nrmse_missing"]), frame(B, lambda b: b["tasks"]["gaps"]["nrmse"])
    pd.DataFrame(dict(median_missing=Wm[METH].median(), rank_missing=Wm[METH].rank(axis=1).mean(),
                      median_full=Wf[METH].median(), rank_full=Wf[METH].rank(axis=1).mean())).to_csv(
        os.path.join(OUT, "table_missing_region113.csv"))
    G0, G1 = frame(B, lambda b: b["tasks"]["gaps"]["nrmse"]), frame(B, lambda b: b["tasks"]["gaps"]["nrmse_mismatch"])
    print("gaps >=50% missing, GP vs LGD:", wil(G1.GaussPrior, G1.LGD))

    # Fig. 1
    lab = {"LGD": "A in init + loop", "LGD_noAloop": "A in init only", "LGD_noAinit": "A in loop only",
           "LGD_noA": "No A (init or loop)"}
    col = {"LGD": COLOR["LGD"], "LGD_noAloop": "#eda100", "LGD_noAinit": "#4a3aa7", "LGD_noA": COLOR["DirectCNN"]}
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.5), sharey=True)
    for ax, t, tl in zip(axes, ["deconv", "gaps", "down"], ["Deconvolution", "Gap filling", "Downsampling"]):
        for ci, c in enumerate(["nrmse", "nrmse_mismatch"] if t != "down" else ["nrmse"]):
            W = frame(B, lambda b: b["tasks"][t][c])
            for yi, v in enumerate(lab):
                ax.scatter(gm(W[v] / W["LGD"]), yi + (0.13 if ci else -0.13), s=28, marker="o" if ci == 0 else "D",
                           facecolor=col[v] if ci == 0 else "white", edgecolor=col[v], lw=1.3, zorder=3)
        ax.axvline(1, color=INK2, lw=0.8, ls="--")
        ax.set_yticks(range(4), list(lab.values()), fontsize=7)
        ax.set_title(tl, fontsize=9)
        ax.set_xlabel("Error / full hybrid (geo. mean)", fontsize=7.5)
        ax.grid(axis="y", visible=False)
    axes[0].invert_yaxis()
    axes[0].scatter([], [], s=28, color=INK2, label="nominal operator")
    axes[0].scatter([], [], s=28, marker="D", facecolor="white", edgecolor=INK2, label="shifted operator (known)")
    fig.legend(*axes[0].get_legend_handles_labels(), loc="lower center", ncol=2, fontsize=7, bbox_to_anchor=(0.55, -0.08))
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"fig_ablation113.{ext}"))
    plt.close(fig)


# ------------------------------------------------------------------ K: sensor changes (deconvolution)
def kernel():
    K = jl(os.path.join(SP, "K"))
    print(f"\n== Kernel study: {len(K)} datasets")
    M = ["Tikhonov", "GaussPrior", "LGD", "PostCNN", "PnP", "DirectCNN", "LGD_noAinit", "LGD_noA"]
    conds = [("nominal", lambda k: k["nominal"])]
    conds += [(f"known x{w}", (lambda w: lambda k: k["known"][w])(w)) for w in ["0.5", "0.75", "1.25", "1.5", "2.0"]]
    conds += [(f"x1.5 supplied {float(e):+.0%}", (lambda e: lambda k: k["shift_misspec"][e])(e)) for e in ["-0.1", "0.1"]]
    conds += [(f"drift {float(e):+.0%} not supplied", (lambda e: lambda k: k["misspec"][e])(e)) for e in ["-0.2", "-0.1", "0.1", "0.2"]]
    nom = frame(K, lambda k: k["nominal"])
    rows = []
    for lab, f in conds:
        X = frame(K, f)
        rk = X[M].rank(axis=1).mean()
        r = dict(condition=lab)
        for m in M:
            r[f"{m}_vs_Tik"] = gm(X[m] / X.Tikhonov)
            r[f"{m}_vs_own_nominal"] = gm(X[m] / nom[m])
            r[f"{m}_rank"] = rk[m]
        w = wil(X.LGD, X.LGD_noAinit)
        r.update(init_gain_pct=100 * (1 - w[3]), init_better=w[0], init_p=w[2])
        w = wil(X.PnP, X.LGD)
        r.update(PnP_vs_LGD=w[3], PnP_better=w[0], PnP_p=w[2])
        rows.append(r)
    T = pd.DataFrame(rows)
    T.to_csv(os.path.join(OUT, "table_kernel.csv"), index=False)
    print(T[["condition", "init_gain_pct", "init_better", "init_p", "PnP_vs_LGD", "PnP_better", "PnP_rank", "LGD_rank"]].round(4).to_string())

    # Fig. 2
    widths = ["0.5", "0.75", "1.0", "1.25", "1.5", "2.0"]
    get = lambda w: nom if w == "1.0" else frame(K, lambda k: k["known"][w])
    meths = [("LGD", "Unrolled LGD (A in init + loop)", COLOR["LGD"], "-o"), ("PostCNN", "CNN post-processing", COLOR["PostCNN"], "-o"),
             ("PnP", "Plug-and-play (PnP)", "#7a3fb0", "-s"), ("GaussPrior", "Learned Gaussian prior", COLOR["GaussPrior"], "-o"),
             ("LGD_noAinit", "Unrolled, A in loop only", "#4a3aa7", "--^"), ("LGD_noA", "Unrolled, no A", COLOR["DirectCNN"], "--v"),
             ("DirectCNN", "Fully learned CNN", "#0b6b4a", ":x")]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.3), gridspec_kw=dict(width_ratios=[1.35, 1]))
    ax = axes[0]
    xs = [float(w) for w in widths]
    for m, l, c, st in meths:
        ax.plot(xs, [gm(get(w)[m] / get(w)["Tikhonov"]) for w in widths], st, color=c, ms=3.5, lw=1.3, label=l)
    ax.axhline(1, color=INK2, lw=0.8, ls="--")
    ax.axvline(1, color=GRID, lw=4, zorder=0)
    ax.set_xlabel("Test kernel width / training width", fontsize=8)
    ax.set_ylabel("Error / Tikhonov (geo. mean)", fontsize=8)
    ax.set_title("(a) Known change of the sensor kernel", fontsize=9)
    ax.set_xticks(xs, [w.rstrip("0").rstrip(".") if w != "1.0" else "1\n(nominal)" for w in widths], fontsize=7)
    ax = axes[1]
    labs, vals, cols = [], [], []
    for w in ["0.5", "0.75", "1.25", "1.5", "2.0"]:
        X = get(w); labs.append(f'×{w.rstrip("0").rstrip(".")}, known'); vals.append(100 * (1 - gm(X.LGD / X.LGD_noAinit))); cols.append(COLOR["LGD"])
    for e in ["0.1", "-0.1"]:
        X = frame(K, lambda k: k["shift_misspec"][e]); labs.append(f"×1.5, width {float(e):+.0%}"); vals.append(100 * (1 - gm(X.LGD / X.LGD_noAinit))); cols.append("#eda100")
    for e in ["-0.2", "-0.1", "0.1", "0.2"]:
        X = frame(K, lambda k: k["misspec"][e]); labs.append(f"drift {float(e):+.0%}, not supplied"); vals.append(100 * (1 - gm(X.LGD / X.LGD_noAinit))); cols.append("#8a8984")
    y = np.arange(len(vals))
    ax.barh(y, vals, color=cols, height=0.65)
    for yi, v in zip(y, vals):
        ax.text(max(v, 0) + 0.6, yi, f"{v:.1f}%", va="center", ha="left", fontsize=6.5, color=INK2)
    ax.set_yticks(y, labs, fontsize=6.8)
    ax.invert_yaxis()
    ax.axvline(0, color=INK2, lw=0.8)
    ax.set_xlabel("Error reduction from operator-based init (%)", fontsize=8)
    ax.set_xlim(-3, 38)
    ax.grid(axis="y", visible=False)
    ax.set_title("(b) Value of operator access", fontsize=9)
    h, l = axes[0].get_legend_handles_labels()
    fig.tight_layout(rect=(0, 0.13, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=4, fontsize=6.5, bbox_to_anchor=(0.5, 0.0))
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"fig_kernel.{ext}"))
    plt.close(fig)


# ------------------------------------------------------------------ P: stronger baselines
def baselines():
    P = jl(os.path.join(SP, "P"))
    print(f"\n== Baselines: {len(P)} datasets: {[p['dataset'] for p in P]}")
    rows = []
    for t, c, s in [("denoise", "nominal", None), ("deconv", "nominal", None), ("deconv", "shift", None), ("gaps", "nominal", "full"),
                    ("gaps", "nominal", "missing"), ("gaps", "shift", "full"), ("gaps", "shift", "missing"), ("down", "nominal", None)]:
        X = frame(P, lambda p: p["tasks"][t][c] if s is None else p["tasks"][t][c][s])
        rk = X.rank(axis=1).mean()
        for m in X.columns:
            rows.append(dict(task=t, cond=c, points=s or "full", method=m, gmean_vs_Tik=gm(X[m] / X.Tikhonov), rank=rk[m]))
        for a, b in [("PnP", "LGD"), ("SAITS", "LGD"), ("SAITS", "DirectCNN"), ("BRITS", "LGD")]:
            if a in X:
                print(t, c, s, a, "vs", b, wil(X[a], X[b]))
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "table_baselines.csv"), index=False)
    print("median SAITS/BRITS training s:", pd.DataFrame([p["tasks"]["gaps"]["train_s"] for p in P]).median().to_dict())


# ------------------------------------------------------------------ N: normalisation
def normalisation():
    N = jl(os.path.join(SP, "N"))
    print(f"\n== Normalisation: {len(N)} datasets")
    rows = []
    for t in ["denoise", "deconv", "gaps", "down"]:
        sub = lambda v: (lambda x: x["tasks"][t][v]["full"] if t == "gaps" else x["tasks"][t][v])
        O = frame(N, sub("oracle"))
        for v in ["oracle", "obs", "obs_cal", "matched"]:
            X = frame(N, sub(v))
            rk = X.rank(axis=1).mean()
            for m in X.columns:
                rows.append(dict(task=t, cond=v, method=m, gmean_vs_oracle=gm(X[m] / O[m]), gmean_vs_Tik=gm(X[m] / X.Tikhonov), rank=rk[m]))
        print(t, "median scale error obs / obs_cal:", np.median([x["tasks"][t]["obs_scale_err"] for x in N]),
              np.median([x["tasks"][t]["obs_cal_scale_err"] for x in N]))
        if t == "gaps":
            for v in ["obs_cal", "matched"]:
                X = frame(N, sub(v))
                print(" ", v, "GP vs Tik", wil(X.GaussPrior, X.Tikhonov), "GP vs LGD", wil(X.GaussPrior, X.LGD), "LGD vs CNN", wil(X.LGD, X.DirectCNN))
            Xm = frame(N, lambda x: x["tasks"]["gaps"]["matched"]["missing"])
            print("  matched, missing points: GP vs LGD", wil(Xm.GaussPrior, Xm.LGD))
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "table_normalisation.csv"), index=False)


# ------------------------------------------------------------------ R: resampling and length
def resampling():
    R = [r for r in jl(os.path.join(SP, "R")) if "prep" in r]
    print(f"\n== Resampling: {len(R)} long datasets, original lengths {min(r['n_orig'] for r in R)}-{max(r['n_orig'] for r in R)}")
    rows, rk = [], {}
    for t, s in [("denoise", None), ("deconv", None), ("deconv_shift", None), ("gaps", "full"), ("gaps", "missing"), ("down", None)]:
        for prep in ["linear", "antialias", "orig"]:
            X = frame(R, lambda r: r["prep"][prep]["tasks"][t] if s is None else r["prep"][prep]["tasks"][t][s])
            M = [m for m in METH if m in X]
            rk[(t, s, prep)] = X[M].rank(axis=1).mean()
            for m in M:
                rows.append(dict(task=t, points=s or "full", prep=prep, method=m, gmean_vs_Tik=gm(X[m] / X.Tikhonov), rank=rk[(t, s, prep)][m],
                                 n_best=int((X[M].idxmin(axis=1) == m).sum())))
            w = wil(X.LGD, X.DirectCNN)
            print(t, s, prep, "LGD vs CNN", w)
        print(t, s, "Spearman of avg ranks: linear-antialias %.3f, linear-orig %.3f" % (
            stats.spearmanr(rk[(t, s, "linear")], rk[(t, s, "antialias")])[0], stats.spearmanr(rk[(t, s, "linear")], rk[(t, s, "orig")])[0]))
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "table_resampling.csv"), index=False)


# ------------------------------------------------------------------ T: training budget, 113 datasets x 3 seeds
def budget():
    T = jl(os.path.join(SP, "T"))
    print(f"\n== Budget: {len(T)} datasets")
    nets = ["LGD", "PostCNN", "DirectCNN"]
    rows = []
    for t in ["gaps", "down"]:
        per = {}
        for b in [500, 2000]:
            per[b] = pd.DataFrame([dict(dataset=x["dataset"], **{m: gm([x["tasks"][t][f"s{s}_{b}"][m] for s in range(3)])
                                                                 for m in ["Tikhonov", "GaussPrior"] + nets}) for x in T]).set_index("dataset")
            rk = per[b].rank(axis=1).mean()
            for m in per[b].columns:
                rows.append(dict(task=t, steps=b, method=m, gmean_vs_Tik=gm(per[b][m] / per[b].Tikhonov), rank=rk[m]))
            print(t, b, "LGD vs CNN", wil(per[b].LGD, per[b].DirectCNN), "GP vs LGD", wil(per[b].GaussPrior, per[b].LGD))
        for m in nets:
            print(t, m, "2000 vs 500 steps", wil(per[2000][m], per[500][m]))
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "table_budget113.csv"), index=False)


# ------------------------------------------------------------------ C: seeded sweep, 11 datasets
def sweep_seeds():
    C = pd.DataFrame(jl(os.path.join(REV, "C")) + jl(os.path.join(REV, "C_extended_5")))
    cols = []
    for m in ["GaussPrior", "LGD", "DirectCNN"]:
        C[m + "_ratio"] = C[m] / C.Tikhonov
        cols.append(m + "_ratio")
    g = C.groupby(["N", "seed"])[cols].apply(lambda d: np.exp(np.log(d).mean()))
    S = g.groupby("N").agg(["mean", "std"])
    beat = C.groupby("N")[cols].apply(lambda d: (d < 1).sum())
    S.columns = ["_".join(c) for c in S.columns]
    S = S.join(beat.add_suffix("_runs_beating_Tik"))
    S.to_csv(os.path.join(OUT, "table_sweep_seeds11.csv"))
    print(f"\n== Seeded sweep: {C.dataset.nunique()} datasets\n", S.round(3).to_string())


# ------------------------------------------------------------------ mechanism diagnostics (Section 4.3, Table S13)
def conv_matrix(n, width):                    # copied from bench.py (which needs PyTorch)
    half = int(np.ceil(4 * width))
    k = np.exp(-0.5 * (np.arange(-half, half + 1) / width) ** 2)
    k /= k.sum()
    A = np.zeros((n, n))
    for i in range(n):
        for j, kv in zip(range(i - half, i + half + 1), k):
            A[i, min(max(j, 0), n - 1)] += kv
    return A


def mechanism(n=256):
    K = jl(os.path.join(SP, "K"))
    w0 = max(1.0, n / 64)
    A0 = conv_matrix(n, w0)
    rel = lambda a, b: np.linalg.norm(a - b, 2) / np.linalg.norm(b, 2)
    nom = frame(K, lambda k: k["nominal"])
    specs = [("nominal", 1, 1, lambda k: k["nominal"])]
    specs += [(f"known x{f}", float(f), float(f), (lambda f: lambda k: k["known"][f])(f)) for f in ["0.5", "0.75", "1.25", "1.5", "2.0"]]
    specs += [(f"x1.5 supplied {float(e):+.0%}", 1.5, 1.5 * (1 + float(e)), (lambda e: lambda k: k["shift_misspec"][e])(e)) for e in ["-0.1", "0.1"]]
    specs += [(f"drift {float(e):+.0%} not supplied", 1 + float(e), 1.0, (lambda e: lambda k: k["misspec"][e])(e)) for e in ["-0.2", "-0.1", "0.1", "0.2"]]
    rows = []
    for lab, tf, sf, f in specs:
        X = frame(K, f)
        At, As = conv_matrix(n, w0 * tf), conv_matrix(n, w0 * sf)
        sv = np.linalg.svd(At, compute_uv=False)
        rows.append(dict(condition=lab, change=rel(At, A0), supplied_error=rel(As, At), n_small_sv=int((sv < 1e-3 * sv[0]).sum()), cond=sv[0] / sv[-1],
                         init_gain_pct=100 * (1 - gm(X.LGD / X.LGD_noAinit)), Tik_vs_nominal=gm(X.Tikhonov / nom.Tikhonov),
                         LGD_vs_Tik=gm(X.LGD / X.Tikhonov), looponly_vs_Tik=gm(X.LGD_noAinit / X.Tikhonov)))
    T = pd.DataFrame(rows)
    # round the spectral quantities: condition numbers near 1e14 differ in the 7th digit between LAPACK builds
    T["cond"] = [float(f"{c:.3g}") for c in T.cond]
    T[["change", "supplied_error"]] = T[["change", "supplied_error"]].round(6)
    T.to_csv(os.path.join(OUT, "table_mechanism.csv"), index=False)
    print("\n== Mechanism diagnostics\n", T.round(3).to_string())
    kn = T[T.condition.str.startswith("known")]
    print("Spearman gain vs change %.2f, vs condition number %.2f, vs small singular values %.2f" % (stats.spearmanr(kn.change, kn.init_gain_pct)[0],
          stats.spearmanr(kn.cond, kn.init_gain_pct)[0], stats.spearmanr(kn.n_small_sv, kn.init_gain_pct)[0]))


# ------------------------------------------------------------------ S: first-order sensor + per-iteration diagnostic (optional)
def sensor():
    folder = os.path.join(SP, "S")
    S = jl(folder) if os.path.isdir(folder) else []
    if not S:
        print("\n== Sensor study: no results in results/sp/S (run bench_sensor.py); skipped")
        return
    print(f"\n== Sensor study: {len(S)} datasets")
    M = ["Tikhonov", "GaussPrior", "LGD", "PostCNN", "PnP", "DirectCNN", "LGD_noAinit", "LGD_noA"]
    conds = [("nominal", lambda x: x["sensor"]["nominal"])]
    conds += [(f"known x{c}", (lambda c: lambda x: x["sensor"]["known"][c])(c)) for c in ["0.5", "0.75", "1.25", "1.5", "2.0"]]
    conds += [(f"x1.5 supplied {float(e):+.0%}", (lambda e: lambda x: x["sensor"]["supplied_err"][e])(e)) for e in ["-0.1", "0.1"]]
    conds += [(f"drift {float(e):+.0%} not supplied", (lambda e: lambda x: x["sensor"]["drift"][e])(e)) for e in ["-0.2", "-0.1", "0.1", "0.2"]]
    rows = []
    for lab, f in conds:
        X = frame(S, f)
        rk = X[M].rank(axis=1).mean()
        r = dict(condition=lab, **{f"{m}_vs_Tik": gm(X[m] / X.Tikhonov) for m in M}, **{f"{m}_rank": rk[m] for m in M})
        if len(X) > 5:
            w = wil(X.LGD, X.LGD_noAinit)
            r.update(init_gain_pct=100 * (1 - w[3]), init_better=w[0], init_p=w[2])
        rows.append(r)
    T = pd.DataFrame(rows)
    T.to_csv(os.path.join(OUT, "table_sensor.csv"), index=False)
    print(T.round(4).to_string())
    # per-iteration diagnostic: geometric mean over datasets of NRMSE after each iteration, relative to Tikhonov at the nominal operator
    rows = []
    for op in ["sensor", "gauss"]:
        for cond in S[0][op]["iterates"]:
            for v in S[0][op]["iterates"][cond]:
                curves = np.array([x[op]["iterates"][cond][v] for x in S])
                for k in range(curves.shape[1]):
                    rows.append(dict(operator=op, condition=cond, variant=v, iteration=k, gmean_nrmse=gm(curves[:, k])))
    I = pd.DataFrame(rows)
    I.to_csv(os.path.join(OUT, "table_iterates.csv"), index=False)
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8), sharey=False)
    sty = {"LGD": (COLOR["LGD"], "-o"), "LGD_noAinit": ("#4a3aa7", "--^"), "LGD_noA": (COLOR["DirectCNN"], ":v")}
    for ax, op, tl in zip(axes, ["gauss", "sensor"], ["Gaussian kernel", "First-order sensor"]):
        for cond, alpha in [("nominal", 0.35), ("known 1.5", 1.0)]:
            for v, (c, st) in sty.items():
                d = I[(I.operator == op) & (I.condition == cond) & (I.variant == v)]
                ax.plot(d.iteration, d.gmean_nrmse, st, color=c, alpha=alpha, ms=3, lw=1.2, label=f"{v}, {cond}" if op == "gauss" else None)
        ax.set_xticks(range(5), ["init", "1", "2", "3", "4"])
        ax.set_xlabel("Unrolled iteration", fontsize=8)
        ax.set_title(tl, fontsize=9)
    axes[0].set_ylabel("NRMSE (geo. mean)", fontsize=8)
    fig.legend(loc="lower center", ncol=3, fontsize=6.5, bbox_to_anchor=(0.5, -0.08))
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"fig_iterates.{ext}"))
    plt.close(fig)


if __name__ == "__main__":
    ablation()
    kernel()
    baselines()
    normalisation()
    resampling()
    budget()
    sweep_seeds()
    mechanism()
    sensor()
